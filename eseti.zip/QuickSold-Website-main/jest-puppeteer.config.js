module.exports = {
	launch: {
        headless: true,
		// slowMo: 50
    },
	server: {
		command: 'npm run start-nobuild',
		launchTimeout: 500
	}
};