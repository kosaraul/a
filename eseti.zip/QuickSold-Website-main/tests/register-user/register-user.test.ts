import { FieldCategory } from '../../src/routes/register-property';
import { expectLogin, user_B } from '../testhelper';

describe('Test register-user static page contents', () => {
    test('Title of the page', async () => {
        await page.goto(URL as any + 'register-user', { waitUntil: 'domcontentloaded' });
        const title: string = await page.title();
        expect(title).toEqual('QuickSold Ingatlan');
    });
});

describe('Test register-user form', () => {
    test('Should not be able to register with incomplete form, form fields should be filled with the incomplete data when showing error messages', async () => {
        await page.goto(URL as any + 'register-user', { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.type('#lastName', 'A');
        await page.type('#firstName', 'B');
        await page.type('#email', 'B@f.h');
        await page.type('#phone', '1');
        await page.type('#company', 'A');
        await page.type('#vatNumber', '1234');
        await page.type('#city', 'A');
        await page.type('#postalCode', '1');
        await page.type('#address', 'A');

        await page.click('[type="submit"]');
        await page.waitForSelector('.error');

        const lastNameError = await page.$eval('.error.lastName', el => el.innerHTML);
        expect(lastNameError).toBe('Helytelen vezetéknév, minimum 3 karakter');

        const firstNameError = await page.$eval('.error.firstName', el => el.innerHTML);
        expect(firstNameError).toBe('Helytelen keresztnév, minimum 3 karakter');

        const emailNameError = await page.$eval('.error.email', el => el.innerHTML);
        expect(emailNameError).toBe('Helytelen e-mail formátum');

        const phoneError = await page.$eval('.error.phone', el => el.innerHTML);
        expect(phoneError).toBe('Helytelen telefonszám formátum (06-30-123-4567)');

        const companyError = await page.$eval('.error.company', el => el.innerHTML);
        expect(companyError).toBe('Helytelen cégnév, minimum 3 karakter');

        const vatNoError = await page.$eval('.error.vatNumber', el => el.innerHTML);
        expect(vatNoError).toBe('Helytelen adószám formátum (12345678-9-01)');

        const cityError = await page.$eval('.error.city', el => el.innerHTML);
        expect(cityError).toBe('Helytelen városnév, minimum 2 karakter');

        const postalError = await page.$eval('.error.postalCode', el => el.innerHTML);
        expect(postalError).toBe('Helytelen irányítószám, 4 karakter');

        const addressError = await page.$eval('.error.address', el => el.innerHTML);
        expect(addressError).toBe('Helytelen cím, minimum 2 karakter');

        const agreeTermsError = await page.$eval('.error.agree-terms', el => el.innerHTML);
        expect(agreeTermsError).toBe('A regisztrációhoz el kell fogadni a feltételeket');

        const userTypeError = await page.$eval('.error.userType', el => el.innerHTML);
        expect(userTypeError).toBe('Kérem válasszon!');

        const lastName = await page.$eval('#lastName', (el) => el.getAttribute('value'));
        expect(lastName).toBe('A');

        const firstName = await page.$eval('#firstName', (el) => el.getAttribute('value'));
        expect(firstName).toBe('B');

        const email = await page.$eval('#email', (el) => el.getAttribute('value'));
        expect(email).toBe('B@f.h');

        const phone = await page.$eval('#phone', (el) => el.getAttribute('value'));
        expect(phone).toBe('1');

        const company = await page.$eval('#company', (el) => el.getAttribute('value'));
        expect(company).toBe('A');

        const vatNo = await page.$eval('#vatNumber', (el) => el.getAttribute('value'));
        expect(vatNo).toBe('1234');

        const city = await page.$eval('#city', (el) => el.getAttribute('value'));
        expect(city).toBe('A');

        const postalCode = await page.$eval('#postalCode', (el) => el.getAttribute('value'));
        expect(postalCode).toBe('1');

        const address = await page.$eval('#address', (el) => el.getAttribute('value'));
        expect(address).toBe('A');
    });

    test('When entering proper data, a success message overlay should be shown, and then disappear on click', async () => {
        await page.goto(URL as any + 'register-user', { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.type('#lastName', user_B.lastName);
        await page.type('#firstName', user_B.firstName);
        await page.type('#email', user_B.email);
        await page.type('#phone', user_B.phone);
        await page.type('#company', 'Gipsz Jakab Kft.');
        await page.type('#vatNumber', '12345678-2-41');
        await page.type('#city', 'Budapest');
        await page.select('#county', 'budapest');
        await page.type('#postalCode', '1111');
        await page.type('#address', 'Kossuth Lajos u. 23.');
        await page.type('#password', user_B.password);
        await page.type('#passwordConf', user_B.password);
        await page.select('#userType', 'owner');
        await page.waitForTimeout(100);
        await page.select('#userType', 'realtor-inactive');
        await page.waitForTimeout(100);
        await page.select('#subscriptionLength', '2');
        await page.click('#agree-terms');
        await page.click('[type="submit"]');
        await page.waitForSelector('.success-msg-overlay-container');

        const successTitle = await page.$eval('.success-msg-overlay-container .title', el => el.innerHTML);
        expect(successTitle).toBe('Sikeres regisztráció');
        const successText = await page.$eval('.success-msg-overlay-container .text', el => el.innerHTML);
        expect(successText).toBe('A regisztráció megerősítésével kapcsolatos tudnivalókat elküldtük e-mail címére');

        await page.click('#dismiss-message');
        const successMsgDisappear = await page.$eval('.success-msg-overlay-container', el => getComputedStyle(el).display);
        expect(successMsgDisappear).toBe('none');
        const overlayDisappear = await page.$eval('.blur-overlay', el => getComputedStyle(el).display);
        expect(overlayDisappear).toBe('none');
    });
});

describe('User should delete themself', () => {
    test('Should login successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.User_B);
    });

    test('Should press delete button, appropriate fields should appear', async () => {
        await page.click('#deleteMyself');
        await page.waitForSelector('#deletion-confirmation');
        const delConf = await page.$('#deletion-confirmation');
        const className: string = await (await delConf.getProperty('className')).jsonValue();
        expect(className.includes('hidden')).toEqual(false);
        expect(className.includes('row')).toEqual(true);
    });

    test('Should type own name into deletion confirmation input field, then should press final delete button, then should be redirected to login page', async () => {
        page.on('dialog', async dialog => {
            await dialog.accept();
        });
        await page.waitForSelector('#typed-name');
        await page.type('#typed-name', user_B.lastName + ' ' + user_B.firstName);
        await page.waitForSelector('#final-delete-button');
        await page.click('#final-delete-button');
        await page.waitForSelector('#e-mail');
        const email = await page.$eval('#e-mail', (el) => el.getAttribute('id'));
        expect(email).toEqual('e-mail');
    });
});