beforeAll(async () => {
    await page.goto(URL as any, { waitUntil: 'domcontentloaded' });
});

describe('Test static page contents', () => {
    test('Title of the page', async () => {
        const title: string = await page.title();
        expect(title).toEqual('QuickSold Ingatlan');
        // toEqual: same value, toBe: same instance
    }, 500);

    test('Test page (sub)titles', async () => {
        const searchValue: string[] = await page.$$eval('.title>.qs-box', (el) => el.map((n) => n.innerHTML));
        expect(searchValue).toEqual(['Tájékoztató', 'Tulajdonosoknak', 'Ingatlanközvetítőknek']);
    }, 500);

    test('Test owner info bubbles` text', async () => {
        const titles: string[] = await page.$$eval('.for-owners.qs-info-container>.qs-info-bubble>p', (e) => e.map((n) => n.innerHTML));
        const texts: string[] = await page.$$eval('.for-owners.qs-info-container>.qs-info-bubble>h1', (e) => e.map((n) => n.innerHTML));
        expect(titles).toEqual(['1', '2', '3', '4']);
        expect(texts).toEqual([
            'Adatok megadása, hirdetés létrehozása',
            'Várja az oldalon regisztrált Ingatlanközvetítők jelentkezését, akik konkrét vásárlójelölttel keresik Önt',
            'Egyeztessenek egy időpontot az ingatlan megtekintésére',
            'Sikeres megtekintés esetén a továbbiakban az Ingatlanközvetítő ügyfelei lesznek'
        ]);
    });

    test('Test realtor info bubbles` text', async () => {
        const titles: string[] = await page.$$eval('.for-realtors.qs-info-container>.qs-info-bubble>p', (e) => e.map((n) => n.innerHTML));
        const texts: string[] = await page.$$eval('.for-realtors.qs-info-container>.qs-info-bubble>h1', (e) => e.map((n) => n.innerHTML));
        expect(titles).toEqual(['1', '2', '3', '4']);
        expect(texts).toEqual([
            'Regisztráció, előfizetés kiválasztása',
            'Belépés után hozzáférnek egy közös állományhoz ahol az adatok mellett a tulajdonosok elérhetőségeit is látni fogják',
            'Ügyfeleik keresési feltételeire rákeresve máris ajánlhatják a talált ingatlant',
            'Sikeres ingatlan megtekintésnél az eseti szerződésüket aláírva az Eladók az Önök ügyfeleik lesznek'
        ]);
    });

    test('Test on-page button Register realtor', async () => {
        const href: string = await page.$eval('#btn-register-user>a', (e) => e.getAttribute('href'));
        const text: string = await page.$eval('#btn-register-user>a', (e) => e.innerHTML);
        expect(href).toEqual('/register-user');
        expect(text).toEqual('Belépés/regisztráció');
    }, 500);

    test('Test on-page button Register property', async () => {
        const href: string = await page.$eval('#btn-register-property>a', (e) => e.getAttribute('href'));
        const text: string = await page.$eval('#btn-register-property>a', (e) => e.innerHTML);
        expect(href).toEqual('/register-property');
        expect(text).toEqual('Hirdetés feladás');
    }, 500);
});


