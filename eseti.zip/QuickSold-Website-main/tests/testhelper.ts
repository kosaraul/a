import { Page } from "puppeteer";
import { fields, errorMessages, FieldCategory } from '../src/routes/register-property';
import path from 'path';

export const user_A = {
    email: 'gipsz@jakab.hu',
    password: 'abc123',
    lastName: 'Gipsz',
    firstName: 'Jakab',
    phone: '06-10-123-4567',
    county: 'budapest',
    city: 'Budapest',
    postalCode: '1132',
    address: 'Lehel u. 88.'
}

export const user_B = {
    email: 'szabo@istvan.hu',
    password: 'abc123',
    lastName: 'Szabo',
    firstName: 'Istvan',
    phone: '06-30-987-6543',
    county: 'budapest',
    city: 'Budapest',
    postalCode: '1012',
    address: 'Varfok utca 9.'
}

export const valid_user = {
    email: 'osku.ambrus@gmail.com',
    password: 'zsoloaz',
    lastName: 'Osku',
    firstName: 'Ambrus',
    phone: '06-30-987-6543',
    county: 'budapest',
    city: 'Budapest',
    postalCode: '1031',
    address: 'Kuzsinszky u 2.'
}


export const isElementVisible = async (page: Page, cssSelector: string) => {
    let visible = true;
    await page.waitForSelector(cssSelector, { visible: true, timeout: 2000 })
        .catch(() => {
            visible = false;
        });
    return visible;
};

async function fillPageWithUserData(page: Page, complete: boolean, user: FieldCategory) {
    if (complete) {
        switch (user) {
            case FieldCategory.User_A:
                await page.type('#email', user_A.email);
                await page.type('#password', user_A.password);
                await page.type('#lastName', user_A.lastName);
                await page.type('#firstName', user_A.firstName);
                await page.type('#phone', user_A.phone);
                break;
            case FieldCategory.User_B:
                await page.type('#email', user_B.email);
                await page.type('#password', user_B.password);
                await page.type('#lastName', user_B.lastName);
                await page.type('#firstName', user_B.firstName);
                await page.type('#phone', user_B.phone);
                break;
        }
    } else {
        await page.type('#email', 'a@b.c');
        await page.type('#password', 'a');
        await page.type('#lastName', 'A');
        await page.type('#firstName', 'B');
    }
}

async function fillPageWithBasicData(page: Page, complete: boolean) {
    if (complete) {
        await page.select('#propertyCounty', 'budapest');
        await page.type('#propertyCity', 'Budapest');
        await page.type('#propertyPostalCode', '1234');
        await page.type('#propertyAddress', 'Petőfi Sándor u. 12.');
        await page.type('#price', '1500000');
        try {
            await page.select('#view', 'panoramic');
            await page.select('#lay', 'south');
        } catch (e) {
            return;
        }
    } else {
        await page.type('#propertyCity', 'A');
        await page.type('#propertyAddress', 'A');
        await page.type('#propertyPostalCode', '1');
        await page.type('#price', '0');
    }
}

async function fillPageWithRentSpecificData(page: Page, complete: boolean) {
    if (complete) {
        await page.type('#utilitiesCost', '15000');
        await page.type('#deposit', '1');
        await page.type('#minimalRentLength', '1');
        await page.select('#moving-in-date-selector', 'select-date');
        await page.waitForSelector('#movingInDate');
        await page.type('#movingInDate', '2021');
        await page.keyboard.press('ArrowRight');
        await page.type('#movingInDate', '12');
        await page.keyboard.press('ArrowRight');
        await page.type('#movingInDate', '08');
        await page.select('#petAllowed', 'yes');
        await page.select('#smokingAllowed', 'no');
    } else {
        await page.type('#minimalRentLength', '0');
        await page.type('#utilitiesCost', '0');
        await page.type('#deposit', '0');
    }
}

export async function fillPropertyForm(page: Page, category: FieldCategory, complete: boolean) {
    switch (category) {
        case FieldCategory.Rent:
            await fillPageWithRentSpecificData(page, complete);
            break;
        case FieldCategory.User_A:
            await fillPageWithUserData(page, complete, category);
            break;
        case FieldCategory.User_B:
            await fillPageWithUserData(page, complete, category);
            break;
        case FieldCategory.Address: // !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            await fillPageWithBasicData(page, complete);
            break;
    }
}

export async function expectLogout() {
    await page.waitForSelector('#nav-link-logout');
    await page.click('#nav-link-logout');
    await page.waitForSelector('form');
    const val = await page.$eval('form', el => el.getAttribute('action'));
    expect(val).toEqual('/login');
}

export async function expectCustomLogin(email: string, password: string) {
    await page.goto(URL as any + 'login', { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('form');
    await page.type('#e-mail', email);
    await page.type('#password', password);
    await page.click('[type="submit"]');
    await page.waitForSelector('#form-change-user-data');
    const emailVal = await page.$eval('#email', (el) => el.getAttribute('value'));
    expect(emailVal).toEqual(email);
}

export async function expectCustomLoginToFail(email: string, password: string) {
    await page.goto(URL as any + 'login', { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('form');
    await page.type('#e-mail', email);
    await page.type('#password', password);
    await page.click('[type="submit"]');
    await page.waitForSelector('.error');
    const emailVal = await page.$eval('.error', (el) => el.innerHTML);
    expect(emailVal).toEqual('Nem megfelelő e-mail cím vagy jelszó');
}

export async function expectLogin(page: Page, user: FieldCategory) {
    await page.goto(URL as any + 'login', { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('form');
    switch (user) {
        case FieldCategory.Valid_User:
            await page.type('#e-mail', valid_user.email);
            await page.type('#password', valid_user.password);
            break;
        case FieldCategory.User_A:
            await page.type('#e-mail', user_A.email);
            await page.type('#password', user_A.password);
            break;
        case FieldCategory.User_B:
            await page.type('#e-mail', user_B.email);
            await page.type('#password', user_B.password);
            break;
    }

    await page.click('[type="submit"]');
    await page.waitForSelector('#form-change-user-data');
    const email = await page.$eval('#email', (el) => el.getAttribute('value'));
    switch (user) {
        case FieldCategory.User_A:
            expect(email).toEqual(user_A.email);
            break;
        case FieldCategory.User_B:
            expect(email).toEqual(user_B.email);
            break;
        case FieldCategory.Valid_User:
            expect(email).toEqual(valid_user.email);
            break;
    }
}

export async function uploadThumbs() {
    const elementHandle = await page.$("input[type=file]");
    let filePaths: string[]= [];
    for (let i = 0; i < 9; i++) {
        const rnd = Math.floor(Math.random() * 10) + 1;
        const filePath = path.relative(process.cwd(), __dirname + '/pics/house-0' + rnd + '.jpg');
        if (filePaths.indexOf(filePath) === -1)
            filePaths.push(filePath);
    }
    await elementHandle.uploadFile(...filePaths);
}

export async function expectPropertyErrors(page: Page, fieldCategory: FieldCategory): Promise<number> {
    const _fields = fields.get(fieldCategory);
    let i = 0;
    _fields.forEach(async (id) => {
        i++;
        const val = await page.$eval('.error.' + id, (e) => e.innerHTML);
        expect(errorMessages.get(id)).toContainEqual(val);
    });
    return i;
}