import { FieldCategory } from "../src/routes/register-property";
import { expectLogin } from "./testhelper";

describe('Test login static page contents', () => {
    test('Title of the page', async () => {
        await page.goto(URL as any + 'login', { waitUntil: 'domcontentloaded' });
        const title: string = await page.title();
        expect(title).toEqual('QuickSold Ingatlan');
    });

    test('Test page (sub)titles', async () => {
        const searchValue: string = await page.$eval('.title>.qs-box', (el) => el.innerHTML);
        expect(searchValue).toEqual('Bejelentkezés');
    });
});

describe('Test login success', () => {
    test('Should log in successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.Valid_User);
    });

    test('Should not be able to login with missing parts, testing password error message', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await page.goto(URL as any + 'login', { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.type('#e-mail', '');
        await page.type('#password', '');

        await page.click('[type="submit"]');
        await page.waitForSelector('.error.password');
        const html = await page.$eval('.error.password', el => el.innerHTML);

        expect(html).toBe('Nem megfelelő e-mail cím vagy jelszó');
    });

    test('Should not be able to login with missing parts, testing e-mail error message', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await page.goto(URL as any + 'login', { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.type('#e-mail', '');
        await page.type('#password', '');

        await page.click('[type="submit"]');
        await page.waitForSelector('.error.password');
        const html = await page.$eval('.error.password', el => el.innerHTML);
        expect(html).toBe('Nem megfelelő e-mail cím vagy jelszó');
    });

    test('Should not be able to login with invalid user account, testing error message', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await page.goto(URL as any + 'login', { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.type('#e-mail', 'osku.ambrus@gmail.com');
        await page.type('#password', 'lofauszt');

        await page.click('[type="submit"]');
        await page.waitForSelector('.error.password');
        const html = await page.$eval('.error.password', el => el.innerHTML);
        expect(html).toBe('Nem megfelelő e-mail cím vagy jelszó');
    });
});