import { testDeposit, testMinimalRentLength, testMovingInDate, testPetAllowed, testSmokingAllowed, testUtilitiesCost, testNewPageDropdown } from "../../../create-sample-db-entries/helper";
import { saleType, type } from './helper';

describe('Properties page, search testing - utilities cost', () => {
    testNewPageDropdown(type, saleType);
    testUtilitiesCost(5000, 10000, 6);
    testNewPageDropdown(type, saleType);
    testUtilitiesCost(10000, 0, 11);
    testNewPageDropdown(type, saleType);
    testUtilitiesCost(0, 4000, 4);
});

describe('Properties page, search testing - deposit', () => {
    testNewPageDropdown(type, saleType);
    testDeposit(1, 2, 14);
    testNewPageDropdown(type, saleType);
    testDeposit(0, 3, 20);
    testNewPageDropdown(type, saleType);
    testDeposit(2, 0, 13);
});

describe('Properties page, search testing - minimal rent length', () => {
    testNewPageDropdown(type, saleType);
    testMinimalRentLength(1, 15, 10);
    testNewPageDropdown(type, saleType);
    testMinimalRentLength(0, 15, 10);
    testNewPageDropdown(type, saleType);
    testMinimalRentLength(15, 0, 10);
});

describe('Properties page, search testing - smoking allowed', () => {
    testNewPageDropdown(type, saleType);
    testSmokingAllowed('yes', 10);
    testNewPageDropdown(type, saleType);
    testSmokingAllowed('no', 10);
});

describe('Properties page, search testing - pet allowed', () => {
    testNewPageDropdown(type, saleType);
    testPetAllowed('yes', 10);
    testNewPageDropdown(type, saleType);
    testPetAllowed('no', 10);
});

describe('Properties page, search testing - moving in date', () => {
    testNewPageDropdown(type, saleType);
    testMovingInDate('2022-02-01', 4);
});