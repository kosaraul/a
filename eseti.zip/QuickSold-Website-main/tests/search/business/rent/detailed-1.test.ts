import { states, buildingYears, testBuildingYear, testState, testStory, testNewPageDropdown } from "../../../create-sample-db-entries/helper";
import { saleType, type } from './helper';

describe('Properties page, search testing - state', () => {
    for (let i = 0; i < states.length; i++) {
        testNewPageDropdown(type, saleType);
        testState(i);
    }
});

describe('Properties page, search testing - story', () => {
    for (let i = 0; i < 17; i++) {
        testNewPageDropdown(type, saleType);
        testStory(i);
    }
});

describe('Properties page, search testing - building year', () => {
    for (let i = 0; i < buildingYears.length; i++) {
        testNewPageDropdown(type, saleType);
        testBuildingYear(i);
    }
});