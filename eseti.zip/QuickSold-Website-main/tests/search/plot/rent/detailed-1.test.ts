import { views, testPrice, testView, testNewPage, testNewPageDropdown, testPlotArea, plotExtras, testPlotExtra } from "../../../create-sample-db-entries/helper";
import { saleType, type } from './helper';


describe('Properties page, search testing - view', () => {
    for (let i = 0; i < views.length; i++) {
        testNewPageDropdown(type, saleType);
        testView(i);
    }
});

describe('Properties page, search testing - extras', () => {
    for (let i = 0; i < plotExtras.length; i++) {
        testNewPageDropdown(type, saleType);
        testPlotExtra(i);
    }
});

describe('Properties page, search testing - price', () => {
    testNewPage(type, saleType);
    testPrice(1, 10, 10);
    testNewPage(type, saleType);
    testPrice(10, 0, 11);
    testNewPage(type, saleType);
    testPrice(0, 10, 10);
});

describe('Properties page, search testing - plot area', () => {
    testNewPage(type, saleType);
    testPlotArea(500, 1000, 6, 'main');
    testNewPage(type, saleType);
    testPlotArea(1000, 0, 11, 'main');
    testNewPage(type, saleType);
    testPlotArea(0, 800, 8, 'main');
});