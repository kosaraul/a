export const saleType = 'rent';
export const type = 'plot';