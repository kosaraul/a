import { comforts, heatings, buildingYears, extras, testComfort, testExtra, testHeating, testBuildingYear, testNewPageDropdown, houseTypes, testHouseType } from "../../../create-sample-db-entries/helper";
import { saleType, type } from './helper';

describe('Properties page, search testing - heating', () => {
    for (let i = 0; i < heatings.length; i++) {
        testNewPageDropdown(type, saleType);
        testHeating(i);
    }
});

describe('Properties page, search testing - comfort', () => {
    for (let i = 0; i < comforts.length; i++) {
        testNewPageDropdown(type, saleType);
        testComfort(i);
    }
});

describe('Properties page, search testing - building year', () => {
    for (let i = 0; i < buildingYears.length; i++) {
        testNewPageDropdown(type, saleType);
        testBuildingYear(i);
    }
});

describe('Properties page, search testing - house type', () => {
    for (let i = 0; i < houseTypes.length; i++) {
        testNewPageDropdown(type, saleType);
        testHouseType(i);
    }
});

describe('Properties page, search testing - extras', () => {
    for (let i = 0; i < extras.length; i++) {
        testNewPageDropdown(type, saleType);
        testExtra(i);
    }
});