import { cities, counties, clickSearchButton, expectResultsCount, testCounty, testCity, testNewPage } from "../../../create-sample-db-entries/helper";

import { saleType, type } from './helper';


describe('Properties page, search testing - HOUSE, RENT; searching without parameters', () => {
    testNewPage(type, saleType);
    test('Should search and find proper number of results; without parameters', async () => {
        await clickSearchButton('main');
        await expectResultsCount(20);
    });
});

describe('Properties page, search testing - counties', () => {
    for (let i = 0; i < counties.length; i++) {
        testNewPage(type, saleType);
        testCounty(counties[i]);
    }
});

describe('Properties page, search testing - cities', () => {
    for (let i = 0; i < cities.length; i++) {
        testNewPage(type, saleType);
        testCity(cities[i]);
    }
});