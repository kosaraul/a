export const saleType = 'rent';
export const type = 'house';