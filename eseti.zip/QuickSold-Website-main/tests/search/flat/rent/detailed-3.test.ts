import { testBaseArea, testHalfRooms, testPrice, testWholeRooms, testNewPage, testNewPageDropdown } from "../../../create-sample-db-entries/helper";
import { saleType, type } from './helper';

describe('Properties page, search testing - price', () => {
    testNewPage(type, saleType);
    testPrice(1, 10, 10);
    testNewPage(type, saleType);
    testPrice(10, 0, 11);
    testNewPage(type, saleType);
    testPrice(0, 10, 10);
});

describe('Properties page, search testing - base area', () => {
    testNewPage(type, saleType);
    testBaseArea(50, 100, 6);
    testNewPage(type, saleType);
    testBaseArea(110, 0, 10);
    testNewPage(type, saleType);
    testBaseArea(0, 80, 8);
});

describe('Properties page, search testing - whole rooms', () => {
    testNewPageDropdown(type, saleType);
    testWholeRooms(3, 10);
});

describe('Properties page, search testing - half rooms', () => {
    testNewPageDropdown(type, saleType);
    testHalfRooms(1, 10);
});