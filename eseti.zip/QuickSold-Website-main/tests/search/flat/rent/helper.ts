export const saleType = 'rent';
export const type = 'flat';