import { buildingMaterials, lays, states, views, testBuildingMaterial, testLay, testState, testStory, testView, testNewPageDropdown } from "../../../create-sample-db-entries/helper";
import { saleType, type } from './helper';

describe('Properties page, search testing - building materials', () => {
    for (let i = 0; i < buildingMaterials.length; i++) {
        testNewPageDropdown(type, saleType);
        testBuildingMaterial(i);
    }
});

describe('Properties page, search testing - lay', () => {
    for (let i = 0; i < lays.length; i++) {
        testNewPageDropdown(type, saleType);
        testLay(i);
    }
});

describe('Properties page, search testing - view', () => {
    for (let i = 0; i < views.length; i++) {
        testNewPageDropdown(type, saleType);
        testView(i);
    }
});

describe('Properties page, search testing - state', () => {
    for (let i = 0; i < states.length; i++) {
        testNewPageDropdown(type, saleType);
        testState(i);
    }
});

describe('Properties page, search testing - story', () => {
    for (let i = 0; i < 17; i++) {
        testNewPageDropdown(type, saleType);
        testStory(i);
    }
});