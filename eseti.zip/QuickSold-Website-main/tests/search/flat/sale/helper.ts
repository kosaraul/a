export const saleType = 'sale';
export const type = 'flat';