import { FieldCategory } from '../../src/routes/register-property';
import { expectLogin, expectCustomLogin, valid_user, expectLogout, expectCustomLoginToFail, fillPropertyForm, isElementVisible } from '../testhelper';

describe('Realtor registers, then tries to see contact info for a property, fails, then admin approves their subscription, then can see contact info', () => {
    test('Should show login page when not logged in', async () => {
        await page.setViewport({ width: 1920, height: 1080 });
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await page.goto(URL as any + 'admin', { waitUntil: 'domcontentloaded' });
        const val = await page.$eval('.qs-section-extra-narrow>.title>.qs-box', (e) => e.innerHTML);
        expect(val).toEqual('Bejelentkezés');
    });

    test('Click on register link, register-user form should appear', async () => {
        await page.waitForSelector('#register-link');
        await page.click('#register-link');
        await page.waitForSelector('form');
        const formAction = await page.$eval('form', el => el.getAttribute('action'));
        expect(formAction).toEqual('/register-user');
    });

    test('Register new user, should be successful', async () => {
        await page.type('#lastName', 'Teszt');
        await page.type('#firstName', 'Teszt');
        await page.type('#password', 'Teszt');
        await page.type('#passwordConf', 'Teszt');
        await page.type('#email', 'teszt@teszt.hu');
        await page.type('#phone', '06-12-345-6789');
        await page.type('#company', 'Teszt ceg');
        await page.type('#vatNumber', '12345678-2-41');
        await page.type('#city', 'Budapest');
        await page.type('#postalCode', '1111');
        await page.type('#address', 'Teszt u. 1.');
        await page.click('#agree-terms');
        await page.select('#county', 'budapest');
        await page.select('#userType', 'realtor-inactive');
        await page.select('#subscriptionLength', '3');
        await page.click('.qs-primary-button');
        await page.waitForSelector('.success-msg-overlay-container');

        const successTitle = await page.$eval('.success-msg-overlay-container .title', el => el.innerHTML);
        expect(successTitle).toBe('Sikeres regisztráció');
    });

    test('Registration confirmation text should be proper', async () => {
        const successText = await page.$eval('.success-msg-overlay-container .text', el => el.innerHTML);
        expect(successText).toBe('A regisztráció megerősítésével kapcsolatos tudnivalókat elküldtük e-mail címére');
    });

    test('After click, success message should disappear', async () => {
        await page.click('#dismiss-message');
        const successMsgDisappear = await page.$eval('.success-msg-overlay-container', el => getComputedStyle(el).display);
        expect(successMsgDisappear).toBe('none');
    });

    test('After click, overlay should disappear', async () => {
        const overlayDisappear = await page.$eval('.blur-overlay', el => getComputedStyle(el).display);
        expect(overlayDisappear).toBe('none');
    });

    test('Realtor should login successfully', async () => {
        await expectCustomLogin('teszt@teszt.hu', 'Teszt');
    });

    test('Navigate to properties page, find property', async () => {
        await page.waitForSelector('#nav-link-properties');
        await page.click('#nav-link-properties');
        await page.waitForSelector('#row-0>.col-xl-4');
        await page.click('#row-0>.col-xl-4');
        await page.waitForSelector('#main-card .qs-box>.title');
        const title = await page.$eval('#main-card .qs-box>.title', el => el.innerHTML);
        expect(title).not.toEqual('');
    });

    test('When clicking on Contact button, nothing should appear', async () => {
        await page.waitForSelector('.qs-secondary-button');
        await page.click('.qs-secondary-button');
        await page.waitForSelector('#contactInfo-box .col-xl-8');
        const title = await page.$eval('#contactInfo-box .col-xl-8', el => el.innerHTML.trim());
        expect(title).toEqual('Csak regisztrált ingatlanosoknak');
    });

    test('Should logout successfully', async () => {
        await expectLogout();
    });

    test('Admin should login successfully', async () => {
        await expectLogin(page, FieldCategory.Valid_User);
    });

    test('Should land on admin page', async () => {
        await page.waitForSelector('#form-change-user-data');
        const email = await page.$eval('#email', el => el.getAttribute('value'));
        expect(email).toEqual('osku.ambrus@gmail.com');
    });

    test('Navigate to Users tab, it should appear', async () => {
        await page.waitForSelector('#users-tablink');
        await page.click('#users-tablink');
        await page.waitForTimeout(500);
        const val = await page.$eval('#users-box', (el) => el.classList.contains('active'));
        expect(val).toEqual(true);
    });

    test('Should find test user among users', async () => {
        const names = await page.$$eval('.row.admin-user-row>.col-sm-3>p', (el) => el.map((n) => {
            return n.innerHTML;
        }));
        expect(names).toContain('Teszt Teszt');
    });
    let id = '';

    test('Should identify row that contains test user', async () => {
        const rowId = await page.$$eval('.row.admin-user-row>.col-sm-3>p', (el) => el.map((n) => {
            if (n.innerHTML === 'Teszt Teszt') {
                return n.parentElement.parentElement.id;
            }
        }));
        for (const r of rowId)
            if (r !== null)
                id = r;
        expect(rowId).toContain(id);
    });

    test('Check user status', async () => {
        const status = await page.$$eval('#' + id + '-user-type-select option', (el) => el.map((n) => {
            if (n.getAttribute('value') === 'realtor-inactive' && n.getAttribute('selected') !== null)
                return true;
            else
                return false;
        }));
        expect(status).toContain(true);
    });

    test('Set user subscription live, navigate to admin page again', async () => {
        let selector = '#' + id + ' .btn-success';
        await page.waitForSelector(selector);
        await page.click(selector);
        await page.waitForSelector('#nav-link-admin');
        await page.click('#nav-link-admin');
        await page.waitForSelector('#form-change-user-data');
        const email = await page.$eval('#email', el => el.getAttribute('value'));
        expect(email).toEqual('osku.ambrus@gmail.com');
    });

    test('Navigate to users page, user status should be realtor', async () => {
        await page.waitForSelector('#users-tablink');
        await page.click('#users-tablink');
        const status = await page.$$eval('#' + id + '-user-type-select option', (el) => el.map((n) => {
            if (n.getAttribute('value') === 'realtor' && n.getAttribute('selected') !== null)
                return true;
            else
                return false;
        }));
        expect(status).toContain(true);
    });

    test('Should logout successfully', async () => {
        await expectLogout();
    });

    test('Realtor should login successfully', async () => {
        await expectCustomLogin('teszt@teszt.hu', 'Teszt');
    });

    test('Navigate to properties page, find property', async () => {
        await page.waitForSelector('#nav-link-properties');
        await page.click('#nav-link-properties');
        await page.waitForSelector('#row-0>.col-xl-4');
        await page.click('#row-0>.col-xl-4');
        await page.waitForSelector('#main-card .qs-box>.title');
        const title = await page.$eval('#main-card .qs-box>.title', el => el.innerHTML);
        expect(title).not.toEqual('');
    });

    test('When clicking on Contact button, contact should appear', async () => {
        await page.waitForSelector('.qs-secondary-button');
        await page.click('.qs-secondary-button');
        const message = await page.$eval('#contactInfo-box .col-xl-8', el => el.innerHTML.trim());
        expect(message).toEqual('Öskü Ambrus');
    });

    test('Should logout successfully', async () => {
        await expectLogout();
    });

    test('Should login successfully with SU', async () => {
        await expectLogin(page, FieldCategory.Valid_User);
    });

    test('Should land on admin page', async () => {
        await page.waitForSelector('#form-change-user-data');
        const email = await page.$eval('#email', el => el.getAttribute('value'));
        expect(email).toEqual('osku.ambrus@gmail.com');
    });

    test('Navigate to Users tab, it should appear', async () => {
        await page.waitForSelector('#users-tablink');
        await page.click('#users-tablink');
        await page.waitForTimeout(500);
        const val = await page.$eval('#users-box', (el) => el.classList.contains('active'));
        expect(val).toEqual(true);
    });

    test('Should find test user among users', async () => {
        const names = await page.$$eval('.row.admin-user-row>.col-sm-3>p', (el) => el.map((n) => {
            return n.innerHTML;
        }));
        expect(names).toContain('Teszt Teszt');
    });

    let deletableId = '';
    test('Should identify row that contains test user', async () => {
        const rowId = await page.$$eval('.row.admin-user-row>.col-sm-3>p', (el) => el.map((n) => {
            if (n.innerHTML === 'Teszt Teszt') {
                return n.parentElement.parentElement.id;
            }
        }));
        for (const r of rowId)
            if (r !== null)
                deletableId = r;
        expect(rowId).toContain(deletableId);
    });

    test('Delete user, Test user should not be found anymore', async () => {
        page.on('dialog', async dialog => {
            await dialog.accept();
        });
        let selector = '#' + deletableId + ' .btn-danger';
        await page.waitForSelector(selector);
        await page.click(selector);

        const names = await page.$$eval('.row.admin-user-row>.col-sm-3>p', (el) => el.map((n) => {
            if (!n.parentElement.parentElement.classList.contains('hidden'))
                return n.innerHTML;
        }));
        expect(names).not.toContain('Teszt Teszt');
    });

    test('Should logout successfully', async () => {
        await expectLogout();
    });

    test('Logging in with now deleted user should not be successful', async () => {
        await expectCustomLoginToFail('teszt@teszt.hu', 'Teszt');
    });
});