import { FieldCategory } from '../../src/routes/register-property';
import { expectLogin, valid_user } from '../testhelper';

beforeAll(async () => {
    await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
    await page.goto(URL as any + 'admin', { waitUntil: 'domcontentloaded' });
});

describe('Test static elements', () => {
    test('Should show login page when not logged in', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await page.goto(URL as any + 'admin', { waitUntil: 'domcontentloaded' });
        const val = await page.$eval('.qs-section-extra-narrow>.title>.qs-box', (e) => e.innerHTML);
        expect(val).toEqual('Bejelentkezés');
    });

    test('Should log in successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.Valid_User);
    });

    test('Title should be Quicksold Ingatlan', async () => {
        await page.goto(URL as any + 'admin', { waitUntil: 'domcontentloaded' });
        const title = await page.title();
        expect(title).toBe('QuickSold Ingatlan');
    });

    test('Admin nav class "admin-nav-tabs" element should be an UL', async () => {
        const val = await page.$eval('.admin-nav-tabs', (el) => el.tagName);
        expect(val).toBe('UL');
    });

    test('Admin nav tabs should contain proper titles', async () => {
        const matches = await page.$$eval('.admin-nav-tabs a', (el) => el.map((n) => n.innerHTML));
        expect(matches).toEqual(['Felhasználók', 'Ingatlanok', 'Profil']);
    });
});