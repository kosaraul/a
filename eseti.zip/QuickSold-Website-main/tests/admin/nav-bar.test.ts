import { FieldCategory } from '../../src/routes/register-property';
import { expectLogin, valid_user } from '../testhelper';

const timeout = 1500;

describe('Test changing tabs', () => {
    test('Should show login page when not logged in', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await page.goto(URL as any + 'admin', { waitUntil: 'domcontentloaded' });
        const val = await page.$eval('.qs-section-extra-narrow>.title>.qs-box', (e) => e.innerHTML);
        expect(val).toEqual('Bejelentkezés');
    });

    test('Should log in successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.Valid_User);
    });

    test('By default, Profile tab should be active', async () => {
        await page.goto(URL as any + 'admin', { waitUntil: 'domcontentloaded' });
        const title = await page.$eval('#profile-box', (el) => el.classList.contains('active'));
        expect(title).toEqual(true);
    });

    test('When clicking on Properties tab, its box should become active', async () => {
        await page.click('#properties-tablink');
        await page.waitForTimeout(500);
        const val = await page.$eval('#properties-box', (el) => el.classList.contains('active'));
        expect(val).toEqual(true);
    });

    test('When clicking on Users tab, its box should become active', async () => {
        await page.click('#users-tablink');
        await page.waitForTimeout(500);
        const val = await page.$eval('#users-box', (el) => el.classList.contains('active'));
        expect(val).toEqual(true);
    });

    test('When clicking on Profile tab, its box should become active', async () => {
        await page.click('#profile-tablink');
        await page.waitForTimeout(500);
        const val = await page.$eval('#profile-box', (el) => el.classList.contains('active'));
        expect(val).toEqual(true);
    });
});