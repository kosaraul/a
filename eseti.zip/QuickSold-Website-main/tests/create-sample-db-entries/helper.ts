import { Page } from "puppeteer";

export function testDropdown() {
    test('Should look for main search button', async () => {
        const saveButton = await page.$eval('#main-search-button', el => el.getAttribute('id'));
        expect(saveButton).toEqual('main-search-button');
        if (saveButton === 'main-search-button') {
            await page.waitForSelector('#detailed-search-toggle-button');
            await page.click('#detailed-search-toggle-button');
        }
    }, 500);

    test('Should look for detailed search button', async () => {
        const saveButton = await page.$eval('#detailed-search-button', el => el.getAttribute('id'));
        expect(saveButton).toEqual('detailed-search-button');
    }, 500);
}

export function testTypeSelect(propertyType: string, saleType: string) {
    test('Should select ' + propertyType + ', ' + saleType + ', latter should be checked', async () => {
        await selectPropertyType(propertyType, saleType);
        await page.waitForSelector('#property-sale-type-' + saleType);
        const saleTypeCB = await page.$('#property-sale-type-' + saleType);
        const isCheckBoxChecked = await (await saleTypeCB.getProperty("checked")).jsonValue();
        expect(isCheckBoxChecked).toEqual(true);
    });

    test('Should select ' + propertyType + ', ' + saleType + ', prior should have proper value', async () => {
        await page.waitForSelector('#property-type');
        const typeInput = await page.$('#property-type');
        const value = await (await typeInput.getProperty("value")).jsonValue();
        expect(value).toEqual(propertyType);
    });
}

export function testSearchBox() {
    test('Should find search box', async () => {
        await page.goto(URL as any + 'properties', { waitUntil: 'domcontentloaded' });
        await page.setViewport({ width: 1920, height: 1080 });
        const elementType = await page.$eval('.qs-search-box #property-sale-type-sale', (el) => el.getAttribute('type'));
        expect(elementType).toBe('radio');
    });
}

export function testMovingInDate(date: string, resultsCount: number) {
    test('movingInDate test: ' + date + ', results should be: ' + resultsCount, async () => {
        await page.waitForSelector('#moving-in-date');
        await page.type('#moving-in-date', date.split('-')[0]);
        await page.keyboard.press('ArrowRight');
        await page.type('#moving-in-date', date.split('-')[1]);
        await page.type('#moving-in-date', date.split('-')[2]);
        await clickSearchButton('detailed');
        await expectResultsCount(resultsCount);
    });
}

export function testPetAllowed(option: string, resultsCount: number) {
    test('Test pet allowed: ' + option + ', results count: ' + resultsCount, async () => {
        await page.waitForSelector('#pet-allowed');
        await page.select('#pet-allowed', option);
        await clickSearchButton('detailed');
        await expectResultsCount(resultsCount);
    });
}

export function testSmokingAllowed(option: string, resultsCount: number) {
    test('Test smoking allowed: ' + option + ', expected results count: ' + resultsCount, async () => {
        await page.waitForSelector('#smoking-allowed');
        await page.select('#smoking-allowed', option);
        await clickSearchButton('detailed');
        await expectResultsCount(resultsCount);
    });
}

export function testMinimalRentLength(min: number, max: number, resultsCount: number) {
    const testDescription = getMinMaxTestDescription('Minimal rent length', min, max, resultsCount);
    test(testDescription, async () => {
        await page.waitForSelector('#minimal-rent-length-min');
        if (min !== 0)
            await page.type('#minimal-rent-length-min', min.toString());
        if (max !== 0)
            await page.type('#minimal-rent-length-max', max.toString());
        await clickSearchButton('detailed');
        await expectResultsCount(resultsCount);
    });
}

export function testDeposit(min: number, max: number, resultsCount: number) {
    const testDescription = getMinMaxTestDescription('Deposit', min, max, resultsCount);
    test(testDescription, async () => {
        await page.waitForSelector('#deposit-min');
        if (min !== 0)
            await page.type('#deposit-min', min.toString());
        if (max !== 0)
            await page.type('#deposit-max', max.toString());
        await clickSearchButton('detailed');
        await expectResultsCount(resultsCount);
    });

}

export function testUtilitiesCost(min: number, max: number, resultsCount: number) {
    const testDescription = getMinMaxTestDescription('Utilities', min, max, resultsCount);
    test(testDescription, async () => {
        await page.waitForSelector('#utilities-monthly-min');
        if (min !== 0)
            await page.type('#utilities-monthly-min', min.toString());
        if (max !== 0)
            await page.type('#utilities-monthly-max', max.toString());
        await clickSearchButton('detailed');
        await expectResultsCount(resultsCount); // 10
    });
}


export function testHalfRooms(min: number, resultsCount: number) {
    test('Test half rooms, min: ' + min + ', expected results count: ' + resultsCount, async () => {
        await page.waitForSelector('#half-rooms');
        if (min !== 0)
            await page.type('#half-rooms', min.toString());
        await clickSearchButton('detailed');
        await expectResultsCount(resultsCount); // 10
    });
}

export function testWholeRooms(min: number, resultsCount: number) {
    test('Test whole rooms, min: ' + min + ', expected results count: ' + resultsCount, async () => {
        await page.waitForSelector('#whole-rooms');
        if (min !== 0)
            await page.type('#whole-rooms', min.toString());
        await clickSearchButton('detailed');
        await expectResultsCount(resultsCount); // 10
    });
}

export function testPlotArea(min: number, max: number, resultsCount: number, searchButtonType: string) {
    const testDescription = getMinMaxTestDescription('Plot area', min, max, resultsCount);
    test(testDescription, async () => {
        await page.waitForSelector('#plot-min-area');
        if (min !== 0)
            await page.type('#plot-min-area', min.toString());
        if (max !== 0)
            await page.type('#plot-max-area', max.toString());
        await clickSearchButton(searchButtonType);
        await expectResultsCount(resultsCount);
    });
}

export function testBaseArea(min: number, max: number, resultsCount: number) {
    const testDescription = getMinMaxTestDescription('Base area', min, max, resultsCount);
    test(testDescription, async () => {
        await page.waitForSelector('#property-min-area');
        if (min !== 0)
            await page.type('#property-min-area', min.toString());
        if (max !== 0)
            await page.type('#property-max-area', max.toString());
        await clickSearchButton('main');
        await expectResultsCount(resultsCount);
    });
}

export function testPrice(min: number, max: number, resultsCount: number) {
    const testDescription = getMinMaxTestDescription('Price', min, max, resultsCount);
    test(testDescription, async () => {
        await page.waitForSelector('#property-min-price');
        if (min !== 0)
            await page.type('#property-min-price', (min * 1000000).toString());
        if (max !== 0)
            await page.type('#property-max-price', (max * 1000000).toString());
        await clickSearchButton('main');
        await expectResultsCount(resultsCount); // 10
    });
}

export function testPlotType(index: number) {
    const plotType = plotTypes[(index % 10)];
    test('Test extras, value: ' + plotType + ', expected result count: 2', async () => {
        await page.waitForSelector('#plot-type');
        await page.select('#plot-type', plotType);
        await clickSearchButton('detailed');
        await expectResultsCount(2);
    });
}

export function testHouseType(index: number) {
    const houseType = houseTypes[(index % 3)];
    let expResCount = 7;
    if (houseType === 'family')
        expResCount = 6;
    test('Test housetype, value: ' + houseType + ', expected result count: ' + expResCount, async () => {
        await page.waitForSelector('#houseType');
        await page.select('#houseType', houseType);
        await clickSearchButton('detailed');
        await expectResultsCount(expResCount);
    });
}

export function testExtra(index: number) {
    const extra = extras[(index % 10)];
    test('Test extras, value: ' + extra + ', expected result count: 2', async () => {
        await page.waitForSelector('#' + extra);
        await page.select('#' + extra, 'on');
        await clickSearchButton('detailed');
        await expectResultsCount(2);
    });
}

export function testPlotExtra(index: number) {
    const extra = plotExtras[(index % 5)];
    test('Test extras, value: ' + extra + ', expected result count: 4', async () => {
        await page.waitForSelector('#' + extra);
        await page.select('#' + extra, 'on');
        await clickSearchButton('detailed');
        await expectResultsCount(4);
    });
}

export function testBuildingYear(index: number) {
    const bYear = buildingYears[(index % 17)];
    let expResCount = 1;
    if (bYear === '2023' || bYear === '2022' || bYear === '2021')
        expResCount = 2;
    test('Test building year, value: ' + bYear + ', expected result count: ' + expResCount, async () => {
        await page.waitForSelector('#property-building-year');
        await page.select('#property-building-year', bYear);
        await clickSearchButton('detailed');
        await expectResultsCount(expResCount);
    });
}

export function testComfort(index: number) {
    const comfort = comforts[(index % 5)];
    test('Test building year, value: ' + comfort + ', expected result count: 4', async () => {
        await page.waitForSelector('#property-comfort');
        await page.select('#property-comfort', comfort);
        await clickSearchButton('detailed');
        await expectResultsCount(4);
    });
}

export function testHeating(index: number) {
    const heating = heatings[(index % 14)];
    let expResCount = 1;
    if (heating === 'gas-zirco' || heating === 'district' || heating === 'district-unique' || heating === 'house-central' || heating === 'house-central-unique' || heating === 'gas-convector')
        expResCount = 2;
    test('Test heating, value: ' + heating + ', expected result count: ' + expResCount, async () => {
        await page.waitForSelector('#property-heating');
        await page.select('#property-heating', heating);
        await clickSearchButton('detailed');
        await expectResultsCount(expResCount);
    });

}

export function testStory(index: number) {
    const story = (index % 17).toString();
    let expResCount = 1;
    if (story === '0' || story === '1' || story === '2')
        expResCount = 2;
    test('Test story, value: ' + story + ', expected result count: ' + expResCount, async () => {
        await page.waitForSelector('#property-story');
        await page.select('#property-story', story);
        await clickSearchButton('detailed');
        await expectResultsCount(expResCount);
    });

}

export function testState(index: number) {
    const state = states[index % 7];
    let expResCount = 3;
    if (state === 'to-be-built')
        expResCount = 2;
    test('Test state, value: ' + state + ', expected result count: ' + expResCount, async () => {
        await page.waitForSelector('#property-state');
        await page.select('#property-state', state);
        await clickSearchButton('detailed');
        await expectResultsCount(expResCount);
    });

}

export function testView(index: number) {
    const view = views[index % 4];
    test('Test state, value: ' + view + ', expected result count: 5', async () => {
        await page.waitForSelector('#property-view');
        await page.select('#property-view', view);
        await clickSearchButton('detailed');
        await expectResultsCount(5);
    });
}

export function testLay(index: number) {
    const lay = lays[index % 10];
    test('Test lay, value: ' + lay + ', expected result count: 2', async () => {
        await page.waitForSelector('#property-lay');
        await page.select('#property-lay', lay);
        await clickSearchButton('detailed');
        await expectResultsCount(2);
    });
}

export function testBuildingMaterial(index: number) {
    const buildingMaterial = buildingMaterials[index % 6];
    let expResCount = 3;
    if (buildingMaterial === 'brick' || buildingMaterial === 'panel')
        expResCount = 4;
    test('Test state, value: ' + buildingMaterial + ', expected result count: ' + expResCount, async () => {
        await page.waitForSelector('#building-material');
        await page.select('#building-material', buildingMaterial);
        await clickSearchButton('detailed');
        await expectResultsCount(expResCount);
    });
}

export function testCity(name: string) {
    test('Test city, value: ' + name + ', expected result count: 1', async () => {
        await page.waitForSelector('#property-city');
        await page.type('#property-city', name);
        await clickSearchButton('main');
        await expectResultsCount(1);
    });
}

export function testCounty(name: string) {
    test('Test county, value: ' + name + ', expected result count: 1', async () => {
        await page.waitForSelector('#county');
        await page.select('#county', name);
        await clickSearchButton('main');
        await expectResultsCount(1);
    });
}

export async function expectResultsCount(n: number) {
    await page.waitForSelector('.qs-property-card');
    const results = await page.$$eval('.qs-property-card', (el) => el.map((n) => {
        return n.parentElement.getAttribute('id');
    }));
    expect(results.length).toEqual(n);
}

export async function clickSearchButton(id: string) {
    await page.waitForSelector('#' + id + '-search-button');
    await page.click('#' + id + '-search-button');
}

export async function selectPropertyType(type: string, saleType: string) {
    await page.waitForSelector("#radio-" + saleType);
    await page.click("#radio-" + saleType);
    await page.waitForSelector("#property-type");
    await page.select("#property-type", type);
}

export async function fillAddress(page: Page, index: number) {
    await page.select('#propertyCounty', counties[index]); // 1 of each
    await page.type('#propertyCity', cities[index]); // 1 of each
    let postalCode = ((index + 1) * 1000).toString();
    postalCode = postalCode.substring(0, 4);
    await page.type('#propertyPostalCode', postalCode); // 1000, 2000 .. 9000, 1000, 1100 .. 1900, 2000
    await page.type('#propertyAddress', addresses[index % 10] + ' ' + (index + 1) + '.');
    await page.type('#price', ((index + 1) * 1000000).toString());
    try {
        await page.select('#view', views[index % 4]); // 5 of each
    } catch {
        return;
    }
}

export async function fillPlotExtras(page: Page, index: number) {
    const selector = '#cb-' + plotExtras[index % 5];
    await page.click(selector);
}

export async function fillExtras(page: Page, index: number) {
    const selector = '#cb-' + extras[index % 10];
    await page.click(selector);
}

export async function fillRentSpecific(page: Page, index: number) {
    await page.type('#utilitiesCost', ((index + 1) * 1000).toString());
    await page.type('#deposit', ((index % 3) + 1).toString());
    await page.type('#minimalRentLength', (((index % 2) + 1) * 12).toString()); // 12, 24; 10 of each
    await page.select('#moving-in-date-selector', 'select-date');
    await page.waitForSelector('#movingInDate');
    await page.type('#movingInDate', '2022');
    await page.keyboard.press('ArrowRight');
    let month = (index % 12) + 1;
    await page.type('#movingInDate', month.toString());
    if (month < 2 || month > 9)
        await page.keyboard.press('ArrowRight');
    await page.type('#movingInDate', '01');
    if (index % 2 == 0)
        await page.select('#petAllowed', 'yes');
    else
        await page.select('#petAllowed', 'no');
    if (index % 2 == 0)
        await page.select('#smokingAllowed', 'no');
    else
        await page.select('#smokingAllowed', 'yes');
}

export const plotTypes = [
    'field',
    'building',
    'forest',
    'vineyard',
    'closedcourt',
    'pasture',
    'orchard',
    'resort',
    'holiday',
    'industrial'
]

export const houseTypes = [
    'twin',
    'row',
    'family'
]

export const plotExtras = [
    'property-water',
    'property-gas',
    'property-electricity',
    'property-drainage',
    'property-fence'
]

export const extras = [
    'property-balcony',
    'property-terrace',
    'property-elevator',
    'property-ac',
    'property-parking-spot',
    'property-garage',
    'property-container',
    'property-cellar',
    'property-pool',
    'property-alarm',
]

export const counties = [
    'baranya',
    'jasznagykun',
    'fejer',
    'hajdubihar',
    'veszprem',
    'zala',
    'bacskiskun',
    'heves',
    'csongrad',
    'gyor',
    'nograd',
    'pest',
    'tolna',
    'budapest',
    'baz',
    'komarom',
    'szabolcs',
    'bekes',
    'somogy',
    'vas'
]

export const cities = [
    'Pécs',
    'Jászberény',
    'Polgárdi',
    'Debrecen',
    'Veszprém',
    'Zalaszentmárton',
    'Bácsalmás',
    'Nyíregyháza',
    'Ajka',
    'Győr',
    'Nógrádsáriszentsáp',
    'Budakalász',
    'Szekszárd',
    'Budapest',
    'Miskolc',
    'Komárom',
    'Szabolcskiskunfélegyháza',
    'Békésszentkálfa',
    'Somogyszentgrót',
    'Szombathely'
]

export const buildingYears = [
    '2023',
    '2022',
    '2021',
    '2020',
    '2019',
    '2018',
    '2017',
    '2016',
    '2015',
    '2014',
    '2013',
    '2012',
    '2011',
    '2010',
    '2000-2009',
    '1980-1999',
    'before1980',
]

export const comforts = [
    'full',
    'double',
    'luxury',
    'half',
    'no-comfort'
]

export const heatings = [
    'gas-zirco',
    'gas-convector',
    'district',
    'district-unique',
    'house-central',
    'house-central-unique',
    'floorheating',
    'wallheating',
    'ceilingheating',
    'heatpump',
    'electric',
    'gasboiler',
    'tiledboiler',
    'generalboiler'
]

export const states = [
    'excellent',
    'good',
    'average',
    'like-new',
    'refurbished',
    'to-refurbish',
    'to-be-built'
]

export const lays = [
    'north',
    'south',
    'east',
    'west',
    'northsouth',
    'northeast',
    'northwest',
    'southeast',
    'southwest',
    'eastwest'
]

export const buildingMaterials = [
    'brick',
    'panel',
    'lightweight',
    'stone',
    'wood',
    'sliding'
]

export const addresses = [
    'Lehel u.',
    'Kossuth Lajos u.',
    'Petőfi Sándor u.',
    'Ady Endre u.',
    'Szabadság út',
    'Podmaniczky u.',
    'Fő tér',
    'Kadosa u.',
    'Monostori út',
    'Nánási út',
]

export const views = [
    'panoramic',
    'garden',
    'court',
    'street'
]

function getMinMaxTestDescription(title: string, min: number, max: number, resultsCount: number): string {
    let testDescription = 'Test ' + title + '. ';
    if (min !== 0 && max !== 0)
        testDescription += 'Min: ' + min + ', max: ' + max;
    else if (min !== 0)
        testDescription += 'Above: ' + min;
    else if (max !== 0)
        testDescription += 'Below: ' + max;
    testDescription += '. Expected results count: ' + resultsCount;
    return testDescription;
}

export async function dropDownDetailedSearch() {
    await page.waitForSelector('#detailed-search-toggle-button');
    await page.click('#detailed-search-toggle-button');
}

export function testNewPageDropdown(type: string, saleType: string) {
    testSearchBox();
    testTypeSelect(type, saleType);
    testDropdown();
}

export function testNewPage(type: string, saleType: string) {
    testSearchBox();
    testTypeSelect(type, saleType);
}