import { expectLogin, uploadThumbs } from '../testhelper';
import { FieldCategory } from '../../src/routes/register-property';
import { fillPlotExtras, fillRentSpecific, fillAddress, plotTypes } from './helper';
const myURL = URL as any + 'register-property';

describe('Login', () => {
    test('Should login successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.Valid_User);
    })
});

for (let i = 0; i < 20; i++) {
    describe('Should create plot for sale, #' + i, () => {
        test('Should show success message for #' + i, async () => {
            await createPlot(i, 'sale');
        });
    });
}

for (let i = 0; i < 20; i++) {
    describe('Should create plot for rent, #' + i, () => {
        test('Should show success message for #' + i, async () => {
            await createPlot(i, 'rent');
        });
    });
}

async function createPlot(index: number, saleType: string) {
    await page.goto(myURL, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('form');
    if (saleType === 'rent')
        await page.click('#select-property-sale-type-for-rent');
    else
        await page.click('#select-property-sale-type-for-sale');
    await page.waitForSelector('#property-type');
    await page.select('#property-type', 'plot');
    if (saleType === 'rent')
        await page.waitForSelector('form#form-register-plot-for-rent');
    else
        await page.waitForSelector('form#form-register-plot-for-sale');

    await fillAddress(page, index);

    await page.type('#plotArea', ((index + 1) * 100).toString());
    await page.select('#plotType', plotTypes[index % 10]); // 2 of each
    await uploadThumbs();

    await fillPlotExtras(page, index);
    if (saleType === 'rent')
        await fillRentSpecific(page, index);

    await page.click('[type="submit"]');
    await page.waitForSelector('.success');
    const successMsg = await page.$eval('.success', (el) => el.innerHTML);
    expect(successMsg).toBe('Hirdetését elmentettük');
}