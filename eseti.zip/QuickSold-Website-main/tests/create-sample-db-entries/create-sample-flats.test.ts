import { expectLogin, uploadThumbs } from '../testhelper';
import { FieldCategory } from '../../src/routes/register-property';
import { lays, states, buildingMaterials, heatings, comforts, buildingYears, fillExtras, fillRentSpecific, fillAddress } from './helper';
const myURL = URL as any + 'register-property';

describe('Login', () => {
    test('Should login successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.Valid_User);
    })
});

for (let i = 0; i < 20; i++) {
    describe('Should create flat for sale, #' + i, () => {
        test('Should show success message for #' + i, async () => {
            await createFlat(i, 'sale');
        });
    });
}

for (let i = 0; i < 20; i++) {
    describe('Should create flat for rent, #' + i, () => {
        test('Should show success message for #' + i, async () => {
            await createFlat(i, 'rent');
        });
    });
}

async function createFlat(index: number, saleType: string) {
    await page.goto(myURL, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('form');
    if (saleType === 'rent')
        await page.click('#select-property-sale-type-for-rent');
    else
        await page.click('#select-property-sale-type-for-sale');
    await page.waitForSelector('#property-type');
    await page.select('#property-type', 'flat');
    if (saleType === 'rent')
        await page.waitForSelector('form#form-register-flat-for-rent');
    else
        await page.waitForSelector('form#form-register-flat-for-sale');

    await fillAddress(page, index);

    await page.type('#baseArea', ((index + 1) * 10).toString());
    await page.select('#buildingMaterial', buildingMaterials[index % 6]); // 3 of each, except 4 brick, 4 panel
    await page.select('#lay', lays[index % 10]); // 2 of each
    await page.select('#state', states[index % 7]); // 3 of each, except 2 to-be-built
    await page.select('#story', (index % 17).toString()); // 1 of each, except 2 of '0', '1', '2'
    await page.type('#halfRooms', (index % 2).toString()); // 0, 1; 10 of each 
    await page.type('#wholeRooms', ((index % 4) + 1).toString()); // 1, 2, 3, 4; 5 of each
    await page.select('#heating', heatings[(index % 14)]); // 1 of each, except 2 of 'gas-zirco', 'gas-convector', 'district', 'district-unique', 'house-central', 'house-central-unique',
    await page.select('#comfort', comforts[(index % 5)]); // 4 of each
    await page.select('#buildingYear', buildingYears[(index % 17)]); // 1 of each, except 2 of '2023', '2022', '2021'
    await uploadThumbs();

    await fillExtras(page, index);
    if (saleType === 'rent')
        await fillRentSpecific(page, index);

    await page.click('[type="submit"]');
    await page.waitForSelector('.success');
    const successMsg = await page.$eval('.success', (el) => el.innerHTML);
    expect(successMsg).toBe('Hirdetését elmentettük');
}