import { expectLogin, uploadThumbs } from '../testhelper';
import { FieldCategory } from '../../src/routes/register-property';
import { lays, states, buildingMaterials, heatings, comforts, buildingYears, fillExtras, fillRentSpecific, fillAddress } from './helper';
const myURL = URL as any + 'register-property';

describe('Login', () => {
    test('Should login successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.Valid_User);
    })
});

for (let i = 0; i < 20; i++) {
    describe('Should create business for sale, #' + i, () => {
        test('Should show success message for #' + i, async () => {
            await createBusiness(i, 'sale');
        });
    });
}

for (let i = 0; i < 20; i++) {
    describe('Should create business for rent, #' + i, () => {
        test('Should show success message for #' + i, async () => {
            await createBusiness(i, 'rent');
        });
    });
}

async function createBusiness(index: number, saleType: string) {
    await page.goto(myURL, { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('form');
    if (saleType === 'rent')
        await page.click('#select-property-sale-type-for-rent');
    else
        await page.click('#select-property-sale-type-for-sale');
    await page.waitForSelector('#property-type');
    await page.select('#property-type', 'business');
    if (saleType === 'rent')
        await page.waitForSelector('form#form-register-business-for-rent');
    else
        await page.waitForSelector('form#form-register-business-for-sale');

    await fillAddress(page, index);

    await page.type('#baseArea', ((index + 1) * 10).toString());
    await page.select('#state', states[index % 7]); // 3 of each, except 2 to-be-built
    await page.select('#story', (index % 17).toString()); // 1 of each, except 1 of '0', '1', '2'
    await page.select('#buildingYear', buildingYears[(index % 17)]); // 1 of each, except 2 of '2023', '2022', '2021'
    await uploadThumbs();
    if (saleType === 'rent')
        await fillRentSpecific(page, index);
    await page.click('[type="submit"]');
    await page.waitForSelector('.success');
    const successMsg = await page.$eval('.success', (el) => el.innerHTML);
    expect(successMsg).toBe('Hirdetését elmentettük');
}