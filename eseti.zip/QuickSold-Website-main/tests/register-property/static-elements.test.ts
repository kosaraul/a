import { FieldCategory } from "../../src/routes/register-property";
import { expectLogin } from "../testhelper";

beforeAll(async () => {
    await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
});

beforeEach(async () => {
    await page.goto(URL as any + 'register-property', { waitUntil: 'domcontentloaded' });
});

const validEmail = 'osku.ambrus@gmail.com';
const validPassword = 'zsoloaz';

describe('Test static elements on register-property page - user not logged in', () => {
    test('Title should be Quicksold Ingatlan', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        const title = await page.title();
        expect(title).toBe('QuickSold Ingatlan');
    });

    test('Subtitle should be proper', async () => {
        const matches = await page.$eval('.title>.qs-box', (el) => el.innerHTML);
        expect(matches).toBe('Ingatlan hirdetése');
    });

    test('Section titles should be proper', async () => {
        const matches = await page.$$eval('.qs-section-title', (el) => el.map((n) => n.innerHTML));
        expect(matches).toEqual(['Hirdető személyes adatai', 'Ingatlan típusa', 'Ingatlan címe', 'Ingatlan adatai', 'Extrák', 'Leírás', 'Képek (0/8)', 'Ingatlanügynöki jutalék']);
    });
});

describe('Test static elements on register-property page - user logged in', () => {
    test('Should log in successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.Valid_User);
    });

    test('Title should be Quicksold Ingatlan', async () => {
        await page.goto(URL as any + 'register-property', { waitUntil: 'domcontentloaded' });
        const title = await page.title();
        expect(title).toBe('QuickSold Ingatlan');
    });

    test('Subtitle should be proper', async () => {
        const matches = await page.$eval('.title>.qs-box', (el) => el.innerHTML);
        expect(matches).toBe('Ingatlan hirdetése');
    });

    test('Section titles should be proper', async () => {
        const matches = await page.$$eval('.qs-section-title', (el) => el.map((n) => n.innerHTML));
        expect(matches).toEqual(['Ingatlan típusa', 'Ingatlan címe', 'Ingatlan adatai', 'Extrák', 'Leírás', 'Képek (0/8)', 'Ingatlanügynöki jutalék']);
    });
});