import { fillPropertyForm, expectPropertyErrors, expectLogin, user_A, user_B } from '../testhelper';
import { FieldCategory } from '../../src/routes/register-property';
const myURL = URL as any + 'register-property';

describe('Test form version Flat-Sale', () => {
    let errorCount = 0;
    let totalErrors = 0;
    test('Should show error messages with incomplete given data, error messages should appear', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await fillPropertyForm(page, FieldCategory.Address, false);
        await fillPropertyForm(page, FieldCategory.User_A, false);
        await page.type('#baseArea', '0');
        await page.click('[type="submit"]');
        await page.waitForSelector('.error');
        const errors = await page.$$eval('.error', (el) => el.map((n) => n.innerHTML));
        totalErrors = errors.length;
        expect(totalErrors).toBeGreaterThan(0);
    });

    test('Flat specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Flat);
    });

    test('Property Address specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Address);
    });

    test('User specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.User_A);
    });

    test('All errors should be tested', async () => {
        expect(errorCount).toEqual(totalErrors);
    });

    test('Should show success message when complete data is input', async () => {
        await browser.newPage();
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await fillPropertyForm(page, FieldCategory.Address, true);
        await fillPropertyForm(page, FieldCategory.User_A, true);
        await page.type('#baseArea', '100');
        await page.select('#buildingMaterial', 'brick');
        await page.select('#lay', 'northeast');
        await page.select('#view', 'panoramic');
        await page.select('#state', 'average');
        await page.select('#story', '5');
        await page.type('#halfRooms', '2');
        await page.type('#wholeRooms', '1');
        await page.select('#heating', 'electric');
        await page.select('#comfort', 'luxury');
        await page.select('#buildingYear', '2016');
        await page.click('#agree-terms');
        await page.click('[type="submit"]');
        await page.waitForSelector('.success');
        const successMsg = await page.$eval('.success', (el) => el.innerHTML);
        expect(successMsg).toBe('Hirdetését elmentettük');
    });

});

describe('Test form version Flat-Rent', () => {
    let errorCount = 0;
    let totalErrors = 0;
    test('Should show error messages with incomplete given data, error messages should appear', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.click('#select-property-sale-type-for-rent');
        await page.waitForSelector('form#form-register-flat-for-rent');
        await fillPropertyForm(page, FieldCategory.Address, false);
        await fillPropertyForm(page, FieldCategory.User_B, false);
        await fillPropertyForm(page, FieldCategory.Rent, false);
        await page.type('#baseArea', '0');
        await page.click('[type="submit"]');
        await page.waitForSelector('.error');
        const errors = await page.$$eval('.error', (el) => el.map((n) => n.innerHTML));
        totalErrors = errors.length;
        expect(totalErrors).toBeGreaterThan(0);
    });

    test('Flat specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Flat);
    });

    test('Property Address specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Address);
    });

    test('User specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.User_A);
    });

    test('Rent specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Rent);
    });

    test('All errors should be tested', async () => {
        expect(errorCount).toEqual(totalErrors);
    });

    test('Should show success message when complete data is input', async () => {
        await browser.newPage();
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.click('#select-property-sale-type-for-rent');
        await page.waitForSelector('form#form-register-flat-for-rent');
        await fillPropertyForm(page, FieldCategory.Address, true);
        await fillPropertyForm(page, FieldCategory.User_B, true);
        await fillPropertyForm(page, FieldCategory.Rent, true);
        await page.type('#baseArea', '100');
        await page.select('#buildingMaterial', 'brick');
        await page.select('#lay', 'northeast');
        await page.select('#view', 'panoramic');
        await page.select('#state', 'average');
        await page.select('#story', '5');
        await page.type('#halfRooms', '2');
        await page.type('#wholeRooms', '1');
        await page.select('#heating', 'electric');
        await page.select('#comfort', 'luxury');
        await page.select('#buildingYear', '2016');
        await page.click('#agree-terms');
        await page.click('[type="submit"]');
        await page.waitForSelector('.success');
        const successMsg = await page.$eval('.success', (el) => el.innerHTML);
        expect(successMsg).toBe('Hirdetését elmentettük');
    });
});

describe('Test form version Flat-Sale - with user logged in', () => {
    let errorCount = 0;
    let totalErrors = 0;

    test('Should login successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.User_A);
    });

    test('Should show error messages with incomplete given data, error messages should appear', async () => {
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await fillPropertyForm(page, FieldCategory.Address, false);
        await page.type('#baseArea', '0');
        await page.click('[type="submit"]');
        await page.waitForSelector('.error');
        const errors = await page.$$eval('.error', (el) => el.map((n) => n.innerHTML));
        totalErrors = errors.length;
        expect(totalErrors).toBeGreaterThan(0);
    });

    test('Flat specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Flat);
    });

    test('Property Address specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Address);
    });

    test('All errors should be tested', async () => {
        expect(errorCount).toEqual(totalErrors);
    });

    test('Should show success message when complete data is input', async () => {
        await browser.newPage();
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await fillPropertyForm(page, FieldCategory.Address, true);
        await page.type('#baseArea', '100');
        await page.select('#buildingMaterial', 'brick');
        await page.select('#lay', 'northeast');
        await page.select('#view', 'panoramic');
        await page.select('#state', 'average');
        await page.select('#story', '5');
        await page.type('#halfRooms', '2');
        await page.type('#wholeRooms', '1');
        await page.select('#heating', 'electric');
        await page.select('#comfort', 'luxury');
        await page.select('#buildingYear', '2016');
        await page.click('[type="submit"]');
        await page.waitForSelector('.success');
        const successMsg = await page.$eval('.success', (el) => el.innerHTML);
        expect(successMsg).toBe('Hirdetését elmentettük');
    });

});

describe('Test form version Flat-Rent - with user logged in', () => {
    let errorCount = 0;
    let totalErrors = 0;
    
    test('Should login successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.User_B);
    });

    test('Should show error messages with incomplete given data, error messages should appear', async () => {
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.click('#select-property-sale-type-for-rent');
        await page.waitForSelector('form#form-register-flat-for-rent');
        await fillPropertyForm(page, FieldCategory.Address, false);
        await fillPropertyForm(page, FieldCategory.Rent, false);
        await page.type('#baseArea', '0');
        await page.click('[type="submit"]');
        await page.waitForSelector('.error');
        const errors = await page.$$eval('.error', (el) => el.map((n) => n.innerHTML));
        totalErrors = errors.length;
        expect(totalErrors).toBeGreaterThan(0);
    });

    test('Flat specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Flat);
    });

    test('Property Address specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Address);
    });

    test('Rent specific errors should appear', async () => {
        errorCount += await expectPropertyErrors(page, FieldCategory.Rent);
    });

    test('All errors should be tested', async () => {
        expect(errorCount).toEqual(totalErrors);
    });

    test('Should show success message when complete data is input', async () => {
        await browser.newPage();
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.click('#select-property-sale-type-for-rent');
        await page.waitForSelector('form#form-register-flat-for-rent');
        await fillPropertyForm(page, FieldCategory.Address, true);
        await fillPropertyForm(page, FieldCategory.Rent, true);
        await page.type('#baseArea', '100');
        await page.select('#buildingMaterial', 'brick');
        await page.select('#lay', 'northeast');
        await page.select('#view', 'panoramic');
        await page.select('#state', 'average');
        await page.select('#story', '5');
        await page.type('#halfRooms', '2');
        await page.type('#wholeRooms', '1');
        await page.select('#heating', 'electric');
        await page.select('#comfort', 'luxury');
        await page.select('#buildingYear', '2016');
        await page.click('[type="submit"]');
        await page.waitForSelector('.success');
        const successMsg = await page.$eval('.success', (el) => el.innerHTML);
        expect(successMsg).toBe('Hirdetését elmentettük');
    });
});

describe('Users should delete themselves - User_A', () => {
    test('Should login successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.User_A);
    });

    test('Should press delete button, appropriate fields should appear', async () => {
        await page.click('#deleteMyself');
        await page.waitForSelector('#deletion-confirmation');
        const delConf = await page.$('#deletion-confirmation');
        const className: string = await (await delConf.getProperty('className')).jsonValue();
        expect(className.includes('hidden')).toEqual(false);
        expect(className.includes('row')).toEqual(true);
    });

    test('Should type own name into deletion confirmation input field, then should press final delete button, then should be redirected to login page', async () => {
        page.on('dialog', async dialog => {
            await dialog.accept();
        });
        await page.waitForSelector('#typed-name');
        await page.type('#typed-name', user_A.lastName + ' ' + user_A.firstName);
        await page.waitForSelector('#final-delete-button');
        await page.click('#final-delete-button');
        await page.waitForSelector('#e-mail');
        const email = await page.$eval('#e-mail', (el) => el.getAttribute('id'));
        expect(email).toEqual('e-mail');
    });
});

describe('Users should delete themselves - User_B', () => {
    test('Should login successfully', async () => {
        await page.goto(URL as any + 'logout', { waitUntil: 'domcontentloaded' });
        await expectLogin(page, FieldCategory.User_B);
    });

    test('Should press delete button, appropriate fields should appear', async () => {
        await page.click('#deleteMyself');
        await page.waitForSelector('#deletion-confirmation');
        const delConf = await page.$('#deletion-confirmation');
        const className: string = await (await delConf.getProperty('className')).jsonValue();
        expect(className.includes('hidden')).toEqual(false);
        expect(className.includes('row')).toEqual(true);
    });

    test('Should type own name into deletion confirmation input field, then should press final delete button, then should be redirected to login page', async () => {
        await page.waitForSelector('#typed-name');
        await page.type('#typed-name', user_B.lastName + ' ' + user_B.firstName);
        await page.waitForSelector('#final-delete-button');
        await page.click('#final-delete-button');
        await page.waitForSelector('#e-mail');
        const email = await page.$eval('#e-mail', (el) => el.getAttribute('id'));
        expect(email).toEqual('e-mail');
    });
});