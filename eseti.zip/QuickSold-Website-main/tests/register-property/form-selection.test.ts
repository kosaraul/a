const myURL = URL as any + 'register-property';

describe('Test form selecting functionality', () => {
    test('When selecting For rent option, a different form should appear', async () => {
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.click('#select-property-sale-type-for-rent');
        await page.waitForSelector('form#form-register-flat-for-rent');
        const formId = await page.$eval('form#form-register-flat-for-rent', (el) => el.id);
        expect(formId).toEqual('form-register-flat-for-rent');
    });

    test('When selecting For rent option, and then plot, a different form should appear', async () => {
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.click('#select-property-sale-type-for-rent');
        await page.waitForSelector('#property-type');
        await page.select('#property-type', 'plot');
        await page.waitForSelector('form#form-register-plot-for-rent');
        const formId = await page.$eval('form#form-register-plot-for-rent', (el) => el.id);
        expect(formId).toEqual('form-register-plot-for-rent');
    });

    test('When selecting For rent option, and then business, a different form should appear', async () => {
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.click('#select-property-sale-type-for-rent');
        await page.waitForSelector('#property-type');
        await page.select('#property-type', 'business');
        await page.waitForSelector('form#form-register-business-for-rent');
        const formId = await page.$eval('form#form-register-business-for-rent', (el) => el.id);
        expect(formId).toEqual('form-register-business-for-rent');
    });

    test('When selecting For rent option, and then house, a different form should appear', async () => {
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.click('#select-property-sale-type-for-rent');
        await page.waitForSelector('#property-type');
        await page.select('#property-type', 'house');
        await page.waitForSelector('form#form-register-house-for-rent');
        const formId = await page.$eval('form#form-register-house-for-rent', (el) => el.id);
        expect(formId).toEqual('form-register-house-for-rent');
    });

    test('When selecting plot as property type, a different form should appear', async () => {
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.select('#property-type', 'plot');
        await page.waitForSelector('form#form-register-plot-for-sale');
        const formId = await page.$eval('form#form-register-plot-for-sale', (el) => el.id);
        expect(formId).toEqual('form-register-plot-for-sale');
    });

    test('When selecting business as property type, a different form should appear', async () => {
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.select('#property-type', 'business');
        await page.waitForSelector('form#form-register-business-for-sale');
        const formId = await page.$eval('form#form-register-business-for-sale', (el) => el.id);
        expect(formId).toEqual('form-register-business-for-sale');
    });

    test('When selecting house as property type, a different form should appear', async () => {
        await page.goto(myURL, { waitUntil: 'domcontentloaded' });
        await page.waitForSelector('form');
        await page.select('#property-type', 'house');
        await page.waitForSelector('form#form-register-house-for-sale');
        const formId = await page.$eval('form#form-register-house-for-sale', (el) => el.id);
        expect(formId).toEqual('form-register-house-for-sale');
    });
});