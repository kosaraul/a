import express from 'express';
import { Request, Response } from 'express';
import PropertyModel, { IProperty, Property } from '../models/property';
import DescriptionModel, { Description } from '../models/description';
import { FilterQuery } from 'mongoose';
import UserModel from '../models/user';

const router = express.Router();

router.get('/', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    let descriptions: Description[] = [];
    let readableProperty = new Property();
    let canEdit = false;
    const contactInfo: any = {};
    const shouldShowContact = req.session.userType === 'realtor' || req.session.userType === 'su' || req.session.userType === 'admin';

    DescriptionModel.find({ 'category': 'property' }).sort({ type: 1, index: 1 })
        .then(result => {
            descriptions = result;
            return PropertyModel.findOne({ '_id': req.query.propId });
        })
        .then(result => {
            if (req.session.userType === 'realtor' || req.session.userType === 'admin' || req.session.userType === 'su') {
                contactInfo.address = result.propertyAddress;
                contactInfo.commissionRate = result.commissionRate;
                if (result.saleType === 'rent')
                    contactInfo.commissionRate += ' hónap';
                else
                    contactInfo.commissionRate += '%';
            }
            readableProperty = createReadableProperty(result, descriptions);
            canEdit = (req.session.userId === result.ownerId || req.session.userType === 'admin' || req.session.userType === 'su');
            return UserModel.findOne({ '_id': result.ownerId })
        })
        .then(result => {
            if (req.session.userType === 'realtor' || req.session.userType === 'admin' || req.session.userType === 'su') {
                contactInfo.phone = result.phone;
                contactInfo.firstName = result.firstName;
                contactInfo.lastName = result.lastName;
                contactInfo.email = result.email;
            }
            return res.render('listing', { auth: req.session.isAuthenticated, name: req.session.name, descriptions, data: readableProperty, contactInfo, canEdit, shouldShowContact, cookieAccepted});
        })
        .catch(err => {
            res.render('error', { errormsg: err, name: req.session.name, cookieAccepted });
        });
});

function createReadableProperty(property: IProperty, descriptions: Description[]): IProperty {
    const readableExtras: [string] = [''];
    readableExtras.pop();
    for (const d of descriptions) {
        if (property.houseType === d.value && d.type === 'house-type')
            property.houseType = d.name;
        if (property.plotType === d.value && d.type === 'plot-type')
            property.plotType = d.name;
        if (property.saleType === d.value && d.type === 'sale-type')
            property.saleType = d.name;
        if (property.buildingMaterial === d.value && d.type === 'building-material')
            property.buildingMaterial = d.name.toLowerCase();
        if (property.type === d.value && d.type === 'property-type')
            property.type = d.name.toLowerCase();
        if (property.view === d.value && d.type === 'property-view')
            property.view = d.name;
        if (property.lay === d.value && d.type === 'property-lay')
            property.lay = d.name;
        if (property.state === d.value && d.type === 'property-state')
            property.state = d.name;
        if (property.heating === d.value && d.type === 'property-heating')
            property.heating = d.name;
        if (property.comfort === d.value && d.type === 'property-comfort')
            property.comfort = d.name;
        if (property.buildingYear === d.value && d.type === 'property-building-year')
            property.buildingYear = d.name;
        if (property.extras.length > 0) {
            if (property.extras.indexOf(d.value) !== -1) {
                readableExtras.push(d.name);
            }
        }
    }
    property.extras = readableExtras;
    return property;
}

export default router;