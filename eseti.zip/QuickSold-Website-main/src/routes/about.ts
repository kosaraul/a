import express from 'express';
import { Request, Response } from 'express';


const router = express.Router();

router.get('/', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    res.render('index', { auth: req.session.isAuthenticated, name: req.session.name, cookieAccepted });
});

router.get('/general-conditions', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    res.render('general-conditions', { auth: req.session.isAuthenticated, name: req.session.name, cookieAccepted });
});

export default router;