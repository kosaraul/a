import express from 'express';
import { Request, Response } from 'express';


const router = express.Router();

router.post('/', (req: Request, res: Response) => {
    req.session.cookieAccepted = true;
    res.send('ok');
});

export default router;