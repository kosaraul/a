import express from 'express';
import { Request, Response } from 'express';
import { body, validationResult } from 'express-validator';
import UserModel, { User, UserSchema } from '../models/user';
import objectify from '../error-objectifier';
import bcrypt from 'bcryptjs';

const router = express.Router();

router.get('/', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    res.render('login', { auth: req.session.isAuthenticated, name: req.session.name, cookieAccepted });
});

router.post('/',
    body('e-mail').isEmail().withMessage('Helytelen e-mail cím'),
    body('password').notEmpty().withMessage('Jelszó nem lehet üres'),
    (req: Request, res: Response) => {
        const cookieAccepted = req.session.cookieAccepted;
        const errors = validationResult(req);
        let userError: object = null;
        let user: any = null;
        UserModel.findOne({ email: (req.body['e-mail'] as string).toLowerCase() })
            .then(result => {
                if (result) {
                    user = result;
                    return bcrypt.compare(req.body.password, result.password)
                } else {
                    userError = { 'password': 'Nem megfelelő e-mail cím vagy jelszó' }
                }
            })
            .then(result => {
                if (result) {
                    if (errors.isEmpty()) {
                        req.session.name = user.firstName;
                        req.session.isAuthenticated = true;
                        req.session.userId = user._id;
                        if (isUserLateWithPayment(user)) {
                            req.session.userType = 'realtor-inactive';
                            UserModel.updateOne({ '_id': user._id }, { $set: { userType: 'realtor-inactive' } })
                                .catch(err => { console.log(err); })
                        } else {
                            req.session.userType = user.userType;
                        }
                        return res.redirect('/admin');
                    }
                    else
                        return res.render('login', { errors: userError ? userError : objectify(errors), auth: req.session.isAuthenticated, name: req.session.name, cookieAccepted });
                }
                else
                    return res.render('login', { errors: { 'password': 'Nem megfelelő e-mail cím vagy jelszó', auth: req.session.isAuthenticated, name: req.session.name }, cookieAccepted });
            })
            .catch(err => {
                res.render('error', { errormsg: err, name: req.session.name, cookieAccepted });
            })
    });

function isUserLateWithPayment(user: User): boolean {
    let isIt = false;
    if (user.userType === 'realtor') {
        const expiryDate = subscriptionExpiry(user);
        const now = new Date().getTime();
        if (expiryDate < now)
            isIt = true;
    }
    return isIt;
}

function subscriptionExpiry(user: User): number {
    const expiryDate = user.lastPaidAt.getTime() + 30 * 24 * 60 * 60 * 1000 * user.subscriptionLength;
    return expiryDate;
}

export default router;