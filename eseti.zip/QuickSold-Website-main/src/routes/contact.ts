import express from 'express';
import { Request, Response } from 'express';
import { body, validationResult } from 'express-validator';
import { emailAddress, sendEmail } from './../emailer';
import objectify from './../error-objectifier';


const router = express.Router();

router.get('/', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    res.render('contact', { auth: req.session.isAuthenticated, name: req.session.name, data: {}, cookieAccepted });
});

router.post('/',
    [body('email')
        .isLength({ min: 1 }).withMessage('Nem lehet üres')
        .isEmail().withMessage('Helytelen e-mail formátum'),
    body('description')
        .isLength({ min: 10 }).withMessage('Üzenet minimum 10 karakter'),
    body('name')
        .isLength({ min: 5 }).withMessage('Név minimum 5 karakter'),
    body('phone')
        .escape()
        .exists({ checkFalsy: true })
        .isLength({min: 11}).withMessage('Adjon meg egy érvényes telefonszámot!')],
    (req: Request, res: Response) => {
        const validationRes = validationResult(req);
        const cookieAccepted = req.session.cookieAccepted;
        if (validationRes.isEmpty()){
            sendEmail(req.body.email, 'Érdeklődés', 'Ön az alábbi tartalmú üzenetet küldte nekünk.\nKöszönjük érdeklődését, hamarosan jelentkezünk.\n' + req.body.description);
            sendEmail(emailAddress, 'Érdeklődés', req.body.email + '\n' + req.body.description);
            return res.render('contact', { auth: req.session.isAuthenticated, name: req.session.name, data: {}, success: 'success', cookieAccepted });
        }
        else
            return res.render('contact', { auth: req.session.isAuthenticated, name: req.session.name, data: req.body, errors: objectify(validationRes), cookieAccepted });
    }
);

export default router;