import express from 'express';
import { Request, Response } from 'express';
import { body, validationResult } from 'express-validator';
import objectify from '../error-objectifier';

const router = express.Router();

router.get('/', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    req.session.username = '';
    req.session.name = '';
    req.session.isAuthenticated = false;
    req.session.userId = '';
    req.session.userType = '';
    res.render('login', {auth: false, name: undefined, cookieAccepted});
});

export default router;