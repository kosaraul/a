import express from 'express';
import { Request, Response } from 'express';
import PropertyModel, { IProperty, Property } from '../models/property';
import DescriptionModel from '../models/description';
import { FilterQuery } from 'mongoose';
import mobile from 'is-mobile';

const router = express.Router();

router.get('/start', (req: Request, res: Response) => {
    req.session.searchParams = {};
    req.session.mobileSearchParams = {};
    return showPage(req, res, { auth: req.session.isAuthenticated, name: req.session.name, saleType: 'sale', propertyType: 'flat', data: {} }, { 'propertyStatus': 'active' });
})

router.get('/', (req: Request, res: Response) => {
    req.session.searchParams = {};
    req.session.mobileSearchParams = {};
    const isMobileReq = mobile({ ua: req });
    if (isMobileReq)
        return showMobileSearchBox(req, res, { auth: req.session.isAuthenticated, name: req.session.name, saleType: 'sale', propertyType: 'flat', data: {} });
    else
        return showPage(req, res, { auth: req.session.isAuthenticated, name: req.session.name, saleType: 'sale', propertyType: 'flat', data: {} }, { 'propertyStatus': 'active' });
});

router.post('/', (req: Request, res: Response) => {
    req.session.searchParams = {};
    const isMobileReq = mobile({ ua: req });
    if (isMobileReq)
        return showMobileSearchBox(req, res, { auth: req.session.isAuthenticated, name: req.session.name, saleType: 'sale', propertyType: 'flat', data: req.session.mobileSearchParams });
    else
        return showPage(req, res, { auth: req.session.isAuthenticated, name: req.session.name, saleType: 'sale', propertyType: 'flat', data: req.body }, { 'propertyStatus': 'active' });
});

router.post('/showmore', (req: Request, res: Response) => {
    const currentPage = req.body.currentPage;
    const searchParameters = req.session.searchParams;
    const cookieAccepted = req.session.cookieAccepted;
    PropertyModel.find(searchParameters).limit(24).skip(currentPage * 24)
        .then(result => {
            return res.send(result);
        })
        .catch(err => {
            return res.render('error', { errormsg: err, name: req.session.name, cookieAccepted });
        });
});

router.post('/plottypes', (req: Request, res: Response) => {
    DescriptionModel.find({ 'type': 'plot-type' })
        .then(result => {
            return res.send(result);
        })
        .catch(err => {
            return res.send('error: ' + err);
        });
});

router.post('/change-type', (req, res) => {
    const searchParameters = getSearchParameters(req);
    req.session.searchParams = searchParameters;
    req.session.mobileSearchParams = req.body;
    const isMobileReq = mobile({ ua: req });
    if (isMobileReq)
        return showMobileSearchBox(req, res, { auth: req.session.isAuthenticated, name: req.session.name, saleType: req.body['property-sale-type-input'], propertyType: req.body['property-type-input'], data: req.body });
    else
        return showPage(req, res, { auth: req.session.isAuthenticated, name: req.session.name, saleType: req.body['property-sale-type-input'], propertyType: req.body['property-type-input'], data: req.body }, searchParameters);
});

router.post('/search', (req, res) => {
    const searchParameters = getSearchParameters(req);
    req.session.searchParams = searchParameters;
    req.session.mobileSearchParams = req.body;
    return showPage(req, res, { auth: req.session.isAuthenticated, name: req.session.name, saleType: req.body['property-sale-type-input'], propertyType: req.body['property-type-input'], data: req.body }, searchParameters);
});

const showMobileSearchBox = (req: Request, res: Response, obj: any) => new Promise((resolve, reject) => {
    const cookieAccepted = req.session.cookieAccepted;
    DescriptionModel.find({ 'category': 'property' }).sort({ type: 1, index: 1 })
        .then(result => {
            obj.descriptions = result;
            obj.cookieAccepted = cookieAccepted;
            res.render('partials/properties/mobile-search-box', obj);
            resolve('ok');
        })
        .catch(err => {
            res.render('error', { errormsg: err, name: req.session.name, cookieAccepted });
            reject(err);
        });
});


export const showPage = (req: Request, res: Response, obj: any, searchParams: FilterQuery<IProperty>) => new Promise((resolve, reject) => {
    const cookieAccepted = req.session.cookieAccepted;
    obj.cookieAccepted = cookieAccepted;
    const isMobileReq = mobile({ ua: req });
    DescriptionModel.find({ 'category': 'property' }).sort({ type: 1, index: 1 })
        .then(result => {
            obj.descriptions = result;
            return PropertyModel.find(searchParams).limit(24);
        })
        .then(result => {
            obj.properties = result;
            if (isMobileReq)
                res.render('properties-mobile', obj);
            else
                res.render('properties', obj);
            resolve('ok');
        })
        .catch(err => {
            res.render('error', { errormsg: err, name: req.session.name, cookieAccepted });
            reject(err);
        });
});

function getSearchParameters(req: Request): FilterQuery<IProperty> {
    const params: FilterQuery<IProperty> = {};
    params.propertyStatus = 'active';
    params.saleType = req.body['property-sale-type-input'];
    params.type = req.body['property-type'];
    if (req.body.county && req.body.county !== 'none')
        params.propertyCounty = req.body.county;
    if (req.body['property-city'] && req.body['property-city'] !== '')
        params.propertyCity = { $regex: req.body['property-city'], $options: 'i' };
    if (req.body['property-min-price'] || req.body['property-max-price'])
        params.price = getMinMaxParams(req.body['property-min-price'], req.body['property-max-price']);
    if (req.body['property-min-area'] || req.body['property-max-area'])
        params.baseArea = getMinMaxParams(req.body['property-min-area'], req.body['property-max-area']);
    if (req.body['plot-min-area'] || req.body['plot-max-area'])
        params.plotArea = getMinMaxParams(req.body['plot-min-area'], req.body['plot-max-area']);
    if (req.body['utilities-monthly-min'] || req.body['utilities-monthly-max'])
        params.utilitiesCost = getMinMaxParams(req.body['utilities-monthly-min'], req.body['utilities-monthly-max']);
    if (req.body['deposit-min'] || req.body['deposit-max'])
        params.deposit = getMinMaxParams(req.body['deposit-min'], req.body['deposit-max']);
    if (req.body['minimal-rent-length-min'] || req.body['minimal-rent-length-max'])
        params.minimalRentLength = getMinMaxParams(req.body['minimal-rent-length-min'], req.body['minimal-rent-length-max']);
    if (req.body['smoking-allowed'] && req.body['smoking-allowed'] !== '' && req.body['smoking-allowed'] !== 'none')
        params.smokingAllowed = req.body['smoking-allowed'];
    if (req.body['pet-allowed'] && req.body['pet-allowed'] !== '' && req.body['pet-allowed'] !== 'none')
        params.petAllowed = req.body['pet-allowed'];
    if (req.body['building-material'] && req.body['building-material'] !== 'none' && req.body['building-material'] !== '')
        params.buildingMaterial = req.body['building-material'];
    if (req.body['property-lay'] && req.body['property-lay'] !== 'none' && req.body['property-lay'] !== '')
        params.lay = req.body['property-lay'];
    if (req.body['property-view'] && req.body['property-view'] !== 'none' && req.body['property-view'] !== '')
        params.view = req.body['property-view'];
    if (req.body['property-state'] && req.body['property-state'] !== 'none' && req.body['property-state'] !== '')
        params.state = req.body['property-state'];
    if (req.body['property-story'] && req.body['property-story'] !== 'none' && req.body['property-story'] !== '')
        params.story = req.body['property-story'];
    if (req.body['property-heating'] && req.body['property-heating'] !== 'none' && req.body['property-heating'] !== '')
        params.heating = req.body['property-heating'];
    if (req.body['property-comfort'] && req.body['property-comfort'] !== 'none' && req.body['property-comfort'] !== '')
        params.comfort = req.body['property-comfort'];
    if (req.body['property-building-year'] && req.body['property-building-year'] !== 'none' && req.body['property-building-year'] !== '')
        params.buildingYear = req.body['property-building-year'];
    if (req.body['whole-rooms'] && req.body['whole-rooms'] > 0 && req.body['whole-rooms'] !== '')
        params.wholeRooms = { $gte: req.body['whole-rooms'] };
    if (req.body['half-rooms'] && req.body['half-rooms'] > 0 && req.body['half-rooms'] !== '')
        params.halfRooms = { $gte: req.body['half-rooms'] };
    if (req.body['plot-type'] && req.body['plot-type'] !== 'none' && req.body['plot-type'] !== '')
        params.plotType = req.body['plot-type'];
    if (req.body.houseType && req.body.houseType !== 'none' && req.body.houseType !== '')
        params.houseType = req.body.houseType;
    if (areThereExtras(req))
        params.extras = { $all: Property.getPropertyExtrasValue(req) };
    if (req.body['moving-in-date'] && req.body['moving-in-date'] !== '')
        params.movingInDate = { $lte: new Date(req.body['moving-in-date']) }
    return params;
}

function areThereExtras(req: Request): boolean {
    if (req.body['property-water'] && req.body['property-water'] === 'on')
        return true;
    if (req.body['property-gas'] && req.body['property-gas'] === 'on')
        return true;
    if (req.body['property-electricity'] && req.body['property-electricity'] === 'on')
        return true;
    if (req.body['property-drainage'] && req.body['property-drainage'] === 'on')
        return true;
    if (req.body['property-fence'] && req.body['property-fence'] === 'on')
        return true;
    if (req.body['property-balcony'] && req.body['property-balcony'] === 'on')
        return true;
    if (req.body['property-terrace'] && req.body['property-terrace'] === 'on')
        return true;
    if (req.body['property-elevator'] && req.body['property-elevator'] === 'on')
        return true;
    if (req.body['property-ac'] && req.body['property-ac'] === 'on')
        return true;
    if (req.body['property-parking-spot'] && req.body['property-parking-spot'] === 'on')
        return true;
    if (req.body['property-garage'] && req.body['property-garage'] === 'on')
        return true;
    if (req.body['property-container'] && req.body['property-container'] === 'on')
        return true;
    if (req.body['property-cellar'] && req.body['property-cellar'] === 'on')
        return true;
    if (req.body['property-pool'] && req.body['property-pool'] === 'on')
        return true;
    if (req.body['property-alarm'] && req.body['property-alarm'] === 'on')
        return true;
}

function getMinMaxParams(min: string, max: string) {
    let price = {};
    if (min && max)
        price = { $gte: min, $lte: max };
    else
        if (min)
            price = { $gte: min };
        else
            price = { $lte: max };
    return price;
}

export default router;