import express from 'express';
import { Request, Response } from 'express';
import UserModel, { User } from '../models/user';
import DescriptionModel, { Description } from '../models/description';
import PropertyModel, { Property } from '../models/property';
const router = express.Router();

router.get('/', (req: Request, res: Response) => {
    if (req.session.isAuthenticated)
        return showFullPage(req, res);
    else
        return res.redirect('/login');
});

router.post('/user/:id', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    if (req.session.userType === 'su' || req.session.userType === 'admin' || req.session.userId === req.params.id) {
        const updatedUser = getUpdatedUser(req);
        UserModel.updateOne({ '_id': req.session.userId }, { $set: updatedUser })
            .then(result => {
                return showFullPage(req, res);
            })
            .catch(err => {
                res.render('error', { errormsg: err, cookieAccepted });
            });
    } else res.render('error', { errormsg: 'Hiányzó jogosultság', cookieAccepted });
});

router.post('/update/:id', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    if (req.session.userType === 'su' || req.session.userType === 'admin' || req.session.userId === req.params.id) {
        UserModel.updateOne({ '_id': req.params.id }, { $set: req.body })
            .then(result => {
                return showFullPage(req, res);
            })
            .catch(err => {
                res.render('error', { errormsg: err, cookieAccepted });
            });
    } else res.render('error', { errormsg: 'Hiányzó jogosultság' });
});

router.post('/delete/:id', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    if (req.session.userType === 'su' || req.session.userType === 'admin' || req.session.userId === req.params.id) {
        PropertyModel.find({ ownerId: req.params.id })
            .then(result => {
                if (result.length > 0)
                    for (const r of result)
                        r.deleteOne();
                return UserModel.deleteOne({ '_id': req.params.id })
            })
            .then(result => {
                return res.send('ok');
            })
            .catch(err => {
                return res.send('error: ' + err);
            });
    } else res.render('error', { errormsg: 'Hiányzó jogosultság', cookieAccepted });
});

router.post('/update-prop/:id', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    PropertyModel.findOne({ '_id': req.params.id })
        .then(result => {
            if (result.ownerId === req.session.userId || req.session.userType === 'su' || req.session.userType === 'admin')
                return PropertyModel.updateOne({ '_id': req.params.id }, { $set: req.body })
            else {
                return;
            }
        })
        .then(result => {
            if (result)
                return showFullPage(req, res);
            else
                return res.render('error', { errormsg: 'Hiányzó jogosultság', cookieAccepted });
        })
        .catch(err => {
            res.render('error', { errormsg: err, cookieAccepted });
        });
});

router.post('/delete-prop/:id', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    PropertyModel.findOne({ '_id': req.params.id })
        .then(result => {
            if (result.ownerId === req.session.userId || req.session.userType === 'su' || req.session.userType === 'admin')
                return result.deleteOne();
            else
                return res.send('Hiányzó jogosultság')
        })
        .then(result => {
            if (result)
                return res.send('ok');
        })
        .catch(err => {
            res.render('error', { errormsg: err, cookieAccepted });
        });
});

const showFullPage = (req: Request, res: Response) => new Promise((resolve, reject) => {
    const cookieAccepted = req.session.cookieAccepted;
    const auth = req.session.isAuthenticated;
    let descriptions: Description[] = [];
    let props: Property[] = [];
    let readableDesc: any = {};
    let currentUser: User;
    DescriptionModel.find({ $or: [{ 'category': 'admin' }, { 'category': 'property' }] }).sort({ type: 1, index: 1 })
        .then(result => {
            descriptions = result;
            readableDesc = objectify(result);
            if (req.session.userType === 'admin' || req.session.userType === 'su')
                return PropertyModel.find({});
            else
                return PropertyModel.find({ ownerId: req.session.userId });
        })
        .then(result => {
            props = result;
            return UserModel.findOne({ '_id': req.session.userId });
        })
        .then(result => {
            currentUser = result;
            return UserModel.find({}).sort({ userType: '1' });
        })
        .then(result => {
            if (auth)
                res.render('admin', {
                    users: result,
                    data: currentUser,
                    properties: props,
                    descriptions,
                    auth,
                    name: req.session.name,
                    readableDesc,
                    userType: req.session.userType,
                    cookieAccepted,
                    subscriptionExpiry: currentUser.lastPaidAt ? subscriptionExpiry(currentUser).toISOString().split('T')[0] : ''
                });
            else
                res.render('login', { auth, name: req.session.name, cookieAccepted });
            resolve('success');
        })
        .catch(err => {
            res.render('error', { errormsg: err, cookieAccepted });
            reject(err);
        });
});

function subscriptionExpiry(user: User): Date {
    const expiryDate = user.lastPaidAt.getTime() + 30 * 24 * 60 * 60 * 1000 * user.subscriptionLength;
    return new Date(expiryDate);
}

function getUpdatedUser(req: Request): any {
    const obj: any = {};
    if (req.body.firstName && req.body.firstName !== '')
        obj.firstName = req.body.firstName;
    if (req.body.lastName && req.body.lastName !== '')
        obj.lastName = req.body.lastName;
    if (req.body.email && req.body.email !== '')
        obj.email = req.body.email;
    if (req.body.password && req.body.password !== '')
        obj.password = req.body.password;
    if (req.body.postalCode && req.body.postalCode !== '')
        obj.postalCode = req.body.postalCode;
    if (req.body.address && req.body.address !== '')
        obj.address = req.body.address;
    if (req.body.county && req.body.county !== '' && req.body.county !== 'none')
        obj.county = req.body.county;
    if (req.body.city && req.body.city !== '')
        obj.city = req.body.city;
    if (req.body.company && req.body.company !== '')
        obj.company = req.body.company;
    if (req.body.vatNumber && req.body.vatNumber !== '')
        obj.vatNumber = req.body.vatNumber;
    return obj;
}

function objectify(descs: Description[]) {
    const obj = {} as any;
    descs.forEach(e => {
        if (e.type === 'sale-type' || e.type === 'property-type')
            obj[e.value] = e.name;
    });
    return obj;
}

export default router;