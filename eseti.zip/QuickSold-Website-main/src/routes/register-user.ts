import express from 'express';
import { Request, Response } from 'express';
import { body, validationResult, ValidationError } from 'express-validator';
import UserModel, { User } from '../models/user';
import objectify from '../error-objectifier';
import DescriptionModel from '../models/description';
import { emailAddress, sendEmail, sendHtmlEmail } from './../emailer';

const router = express.Router();

router.get('/', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    DescriptionModel.find({}).sort({ type: 1, index: 1 })
        .then(result => {
            res.render('register-user', { auth: req.session.isAuthenticated, name: req.session.name, descriptions: result, cookieAccepted });
        })
        .catch(err => {
            res.render('error', { errormsg: err, name: req.session.name, cookieAccepted })
        });
});

router.get('/delete', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    UserModel.deleteOne({ email: req.query.email })
        .then(value => {
            res.send('Deleted: ' + req.query.email);
        })
        .catch(err => {
            res.render('error', { errormsg: err, name: req.session.name, cookieAccepted })
        });
});

router.post('/extend-subscription', (req: Request, res: Response) => {
    UserModel.findOne({ '_id': req.session.userId })
        .then(result => {
            sendHtmlEmail(result.email, 'Előfizetés meghosszabbítása',
                '',
                '<!DOCTYPE html>' +
                '<h3>Kedves Előfizetőnk!</h3>' +
                '<html><head><title>Előfizetés meghosszabbítása</title>' +
                '</head><body><div>' +
                '<p>Köszönjük, igényét feldolgozzuk és hamarosan jelentkezünk.</p><p>A fizetéshez szükséges adatokat a következő e-mailünkben találja.</p><p>További szép napot!</p><p>Sikeres értékesítéseket kívánunk!</p><p>Üdvözlettel: Quick Sold Csapata</p>'
                + '</div></body></html>');
            sendEmail(emailAddress, 'Előfizetés meghosszabbítása', 'Az alábbi felhasználó előfizetés meghosszabbítási kérelmet küldött: ' + result.email);
            res.send('ok');
        });

});

router.post('/',
    body('lastName').isLength({ min: 3 }).withMessage('Helytelen vezetéknév, minimum 3 karakter'),
    body('firstName').isLength({ min: 3 }).withMessage('Helytelen keresztnév, minimum 3 karakter'),
    body('email').isEmail().withMessage('Helytelen e-mail formátum'),
    body('phone')
        .exists({ checkFalsy: true })
        .isLength({ min: 11 }).withMessage('Adjon meg egy érvényes telefonszámot!'),
    body('company').isLength({ min: 3 }).withMessage('Helytelen cégnév, minimum 3 karakter'),
    body('vatNumber')
        .escape()
        .exists({ checkFalsy: true })
        .matches('[0-9]{8}-[0-9]{1}-[0-9]{2}')
        .withMessage('Helytelen adószám formátum (12345678-9-01)'),
    body('city').isLength({ min: 2 }).withMessage('Helytelen városnév, minimum 2 karakter'),
    body('postalCode').isLength({ min: 4, max: 4 }).withMessage('Helytelen irányítószám, 4 karakter'),
    body('address').isLength({ min: 2 }).withMessage('Helytelen cím, minimum 2 karakter'),
    body('agree-terms')
        .custom(value => {
            if (value !== 'on') {
                throw new Error('err')
            } else {
                return value;
            }
        }).withMessage('A regisztrációhoz el kell fogadni a feltételeket'),
    body('password')
        .isLength({ min: 3 }).withMessage('A jelszó minimum 3 karakter'),
    body('passwordConf')
        .isLength({ min: 3 }).withMessage('A jelszó minimum 3 karakter'),
    body('subscriptionLength')
        .custom(value => {
            if (value === 'none') {
                throw new Error('err')
            } else {
                return value;
            }
        }).withMessage('Kérem válasszon!'),
    (req: Request, res: Response) => {
        const cookieAccepted = req.session.cookieAccepted;
        const errors = validationResult(req);
        let descriptions: any = [];
        DescriptionModel.find({}).sort({ type: 1, index: 1 })
            .then(result => {
                descriptions = result;
                return UserModel.find({ email: req.body.email })
            })
            .then(u => {
                if (u.length > 0) {
                    const emailsErrors = objectify(errors);
                    emailsErrors.email = 'Ez az e-mail cím már létezik rendszerünkben';
                    res.render('register-user', { errors: emailsErrors, data: req.body, auth: req.session.isAuthenticated, name: req.session.name, descriptions, cookieAccepted });
                } else
                    if (errors.isEmpty() || onlyForeignErrors(req)) {
                        if (req.body.password === req.body.passwordConf) {
                            UserModel.create({
                                firstName: req.body.firstName,
                                lastName: req.body.lastName,
                                email: req.body.email,
                                phone: req.body.phone,
                                companyName: req.body.company,
                                vatNumber: req.body.vatNumber,
                                address: req.body.address,
                                city: req.body.city,
                                postalCode: req.body.postalCode,
                                userType: 'realtor-inactive',
                                registeredAt: new Date(Date.now()),
                                subscriptionLength: req.body.subscriptionLength === 'none' ? 0 : req.body.subscriptionLength,
                                lastPaidAt: null,
                                password: req.body.password
                            })
                                .then((document) => {
                                    req.session.userId = document._id.toString();
                                    req.session.userType = document.userType;
                                    req.session.isAuthenticated = true;
                                    req.session.name = document.firstName;
                                    sendHtmlEmail(req.body.email, 'Regisztráció',
                                        '',
                                        '<!DOCTYPE html>' +
                                        '<h3>Kedves Előfizetőnk!</h3>' +
                                        '<html><head><title>Regisztráció</title>' +
                                        '</head><body><div>' +
                                        '<p>Örömmel tájékoztatjuk, hogy regisztrációja sikeres volt! Feldolgozzuk megrendelését és hamarosan jelentkezünk.</p><p>A fizetéshez szükséges adatokat a következő e-mailünkben találja.</p><p>További szép napot!</p><p>Sikeres értékesítéseket kívánunk!</p><p>Üdvözlettel: Quick Sold Csapata</p>'
                                        + '</div></body></html>');
                                    sendEmail('info@quicksold.hu', 'Regisztráció', 'Új felhasználó regisztrált. Adatok: ' + document);
                                    res.render('register-user', { success: 'success', auth: req.session.isAuthenticated, name: req.session.name, descriptions, cookieAccepted });
                                })
                                .catch(err => {
                                    res.render('error', { errormsg: err, name: req.session.name })
                                })
                        } else {
                            const passwordErrors = objectify(errors);
                            passwordErrors.password = 'A két jelszó nem egyezik';
                            res.render('register-user', { errors: passwordErrors, data: req.body, auth: req.session.isAuthenticated, name: req.session.name, descriptions, cookieAccepted });
                        }

                    } else {
                        console.log('wtf')
                        res.render('register-user', { errors: objectify(errors), data: req.body, auth: req.session.isAuthenticated, name: req.session.name, descriptions, cookieAccepted });
                    }
            })
            .catch(err => {
                res.render('error', { errormsg: err, name: req.session.name, cookieAccepted })
            });
    });

function onlyForeignErrors(req: Request): boolean {
    const errors = validationResult(req).array();
    let isThere = false;
    errors.forEach(e => {
        if (req.body.userType === 'owner')
            if (e.param === 'subscriptionLength')
                isThere = true;
    });
    return isThere;

}

export default router;