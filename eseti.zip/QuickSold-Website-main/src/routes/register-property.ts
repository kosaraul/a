import express from 'express';
import { Request, Response } from 'express';
import { Types } from 'mongoose';
import { body, validationResult, ValidationError } from 'express-validator';
import PropertyModel, { Property } from '../models/property';
import DescriptionModel from '../models/description';
import UserModel, { User } from '../models/user';
import validate from '../property-validator';
import objectify from '../error-objectifier';
import multer from 'multer';
import { deleteFile } from '../aws';

const storage = multer.diskStorage({
    destination(req, file, cb) {
        cb(null, './uploads')
    },
    filename(req, file, cb) {
        const splitName = file.originalname.split('.');
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9) + '.' + splitName[splitName.length - 1];
        cb(null, file.fieldname + '-' + uniqueSuffix)
    }
});

const upload = multer({ storage })

export enum FieldCategory {
    None = 'none',
    House = 'house',
    Flat = 'flat',
    Plot = 'plot',
    Business = 'business',
    Rent = 'rent',
    Address = 'address',
    User_A = 'user_a',
    User_B = 'user_b',
    User_C = 'user_c',
    User_D = 'user_d',
    Valid_User = 'valid_user'
}

const router = express.Router();
const success = 'success';

router.get('/', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    const saleType = 'sale';
    const propertyType = 'flat';
    const auth = req.session.isAuthenticated ? req.session.isAuthenticated : false;
    DescriptionModel.find({ 'category': 'property' }).sort({ type: 1, index: 1 })
        .then(result => res.render('register-property', { saleType, propertyType, descriptions: result, auth, name: req.session.name , cookieAccepted}))
        .catch(err => res.render('error', { errormsg: err, name: req.session.name, cookieAccepted }));
});

router.get('/edit', (req: Request, res: Response) => {
    const cookieAccepted = req.session.cookieAccepted;
    const auth = req.session.isAuthenticated ? req.session.isAuthenticated : false;
    let prop: Property = new Property();
    let propId: string = '';
    let ownerId = '';
    PropertyModel.findOne({ '_id': req.query.propId })
        .then(result => {
            prop = result;
            ownerId = result.ownerId;
            propId = result._id.toString();
            return DescriptionModel.find({ 'category': 'property' }).sort({ type: 1, index: 1 })
        })
        .then(result => {
            const uploadedFiles = getUploadedFilesFromProperty(prop);
            if (req.session.userType === 'su' || req.session.userType === 'admin' || ownerId === req.session.userId) {
                if (req.query.success)
                    return res.render('register-property', { success: 'success', saleType: prop.saleType, propertyType: prop.type, descriptions: result, auth, name: req.session.name, data: prop, prop, propId, uploadedFiles, cookieAccepted });
                else
                    return res.render('register-property', { saleType: prop.saleType, propertyType: prop.type, descriptions: result, auth, name: req.session.name, data: prop, prop, propId, uploadedFiles, cookieAccepted });
            }
            else
                res.render('error', { errormsg: 'Hiányzó jogosultság', name: req.session.name, cookieAccepted })
        })
        .catch(err => res.render('error', { errormsg: err, name: req.session.name, cookieAccepted }));
});

router.post('/change-type', (req: Request, res: Response) => {
    const saleType = req.body['sale-type'];
    const propertyType = req.body['property-type-input'];
    const auth = req.session.isAuthenticated ? req.session.isAuthenticated : false;
    const prop = createPropertyModel(req, req.session.userId);
    const propId = req.body.propId;
    const cookieAccepted = req.session.cookieAccepted;
    DescriptionModel.find({ 'category': 'property' }).sort({ type: 1, index: 1 })
        .then(result => res.render('register-property', { saleType, propertyType, descriptions: result, data: req.body, auth, name: req.session.name, prop, propId, cookieAccepted }))
        .catch(err => res.render('error', { errormsg: err, name: req.session.name, cookieAccepted }));
});

router.post('/:saleType/:propertyType',
    upload.array('photos', 10),
    validate(),
    (req: Request, res: Response) => {
        renderPage(req, res);
    }
);

function renderPage(req: Request, res: Response) {
    const cookieAccepted = req.session.cookieAccepted;
    const saleType = req.body['sale-type'];
    const propertyType = req.body['property-type-input'];
    const auth = req.session.isAuthenticated ? req.session.isAuthenticated : false;
    DescriptionModel.find({ 'category': 'property' }).sort({ type: 1, index: 1 })
        .then(result => {
            const validationRes = validationResult(req);
            const errors = objectify(validationRes);
            const onlyForeignErrors = isThereOnlyForeignErrors(req);
            const descriptions = result;
            if (validationRes.isEmpty() || onlyForeignErrors) {
                if (req.session.isAuthenticated) {
                    // Be vagyunk jelentkezve, letrehozzuk az ingatlant, es
                    // a session felhasznalojat rendeljuk hozza
                    createProperty(req, req.session.userId)
                        .then((id) => {
                            return res.redirect('/register-property/edit?propId=' + id + '&success=true');
                            // return res.render('register-property', { success, saleType, propertyType, descriptions, auth, name: req.session.name });
                        }).catch(err => res.render('error', { errormsg: err, name: req.session.name, cookieAccepted }));
                } else {
                    checkIfEmailExists(req.body.email)
                        .then(doesIt => {
                            if (doesIt) {
                                // Letezik az e-mail cim, hibauzenetet kuldunk
                                // Render page with error message
                                const uploadedFiles = getUploadedFiles(req);
                                const prop = createPropertyModel(req, req.session.userId);
                                return res.render('register-property', { errors: { 'email': 'Ez az e-mail cím már létezik rendszerünkben' }, data: req.body, saleType, propertyType, descriptions, auth, name: req.session.name, uploadedFiles, prop, cookieAccepted });
                            } else {
                                // VAGY
                                // Nem letezik az e-mail cim, letrehozzuk a felhasznalot,
                                // es az ingatlant
                                createUser(req)
                                    .then((id) => {
                                        return createProperty(req, id.toString());
                                    })
                                    .then((id) => {
                                        return res.redirect('/register-property/edit?propId=' + id + '&success=true');
                                        // return res.render('register-property', { success, saleType, propertyType, descriptions, auth, name: req.session.name });
                                    }).catch(err => res.render('error', { errormsg: err, name: req.session.name , cookieAccepted}));
                            }
                        })
                }
            } else {
                const prop = createPropertyModel(req, req.session.userId);
                const uploadedFiles = getUploadedFiles(req);
                return res.render('register-property', { errors, data: req.body, saleType, propertyType, descriptions: result, auth, name: req.session.name, uploadedFiles, prop, propId: req.body.propId, cookieAccepted });
            }
        })
        .catch(err => res.render('error', { errormsg: err, name: req.session.name, cookieAccepted }));
}

router.post('/remove-photo', (req: Request, res: Response) => {
    PropertyModel.findOne({ '_id': req.body._id })
        .then(result => {
            const thumbs = result.thumbs;
            const newThumbs: [string] = [''];
            newThumbs.pop();
            if (thumbs.indexOf(req.body.fileName) !== -1) {
                thumbs.forEach(e => {
                    if (e !== req.body.fileName)
                        newThumbs.push(e);
                })
            }
            return PropertyModel.updateOne({ '_id': req.body._id }, { $set: { thumbs: newThumbs } });
        })
        .then(result => {
            return deleteFile(req.body.fileName)
        })
        .then(result => {
            return res.send('ok');
        })
        .catch(err => {
            res.send('error:' + err);
        })
});

router.post('/set-image-as-cover', (req: Request, res: Response) => {
    PropertyModel.findOne({ '_id': req.body._id })
        .then(result => {
            const thumbs = result.thumbs;
            const newThumbs: [string] = [''];
            newThumbs.pop();
            newThumbs.push(req.body.fileName);
            if (thumbs.indexOf(req.body.fileName) !== -1) {
                thumbs.forEach(e => {
                    if (e !== req.body.fileName)
                        newThumbs.push(e);
                })
            }
            return PropertyModel.updateOne({ '_id': req.body._id }, { $set: { thumbs: newThumbs } });
        })
        .then(result => {
            return res.send('ok');
        })
        .catch(err => {
            return res.send('error:' + err);
        })
});

class UploadedFile {
    originalname: string;
    filename: string;
}

function getUploadedFilesFromProperty(prop: Property): UploadedFile[] {
    const uploadedFiles: UploadedFile[] = [];
    if (prop.thumbs && prop.thumbs.length > 0) {
        for (const t of prop.thumbs) {
            const uploadedFile = new UploadedFile();
            uploadedFile.originalname = 'none';
            uploadedFile.filename = t;
            uploadedFiles.push(uploadedFile);
        }
    }
    return uploadedFiles;
}

function getUploadedFiles(req: Request): UploadedFile[] {
    const uploadedFiles: UploadedFile[] = [];
    if (req.files && Array.isArray(req.files) && req.files.length > 0)
        for (const f of req.files) {
            const uploadedFile = new UploadedFile();
            uploadedFile.originalname = f.originalname;
            uploadedFile.filename = f.filename;
            uploadedFiles.push(uploadedFile);
        }
    if (req.body['uploadedFiles-name'] && req.body['uploadedFiles-name'].length > 0) {
        const names = req.body['uploadedFiles-name'].split('+');
        for (const name of names) {
            const filename = name.split(',')[0];
            const originalname = name.split(',')[1];
            const uploadedFile = new UploadedFile();
            uploadedFile.filename = filename;
            uploadedFile.originalname = originalname;
            if (uploadedFiles.indexOf(uploadedFile) === -1) {
                uploadedFiles.push(uploadedFile);
            } else console.log('Uploaded file already found');
        }
    }
    return uploadedFiles;
}

const checkIfEmailExists = (emailAddress: string) => new Promise((resolve, reject) => {
    UserModel.find({ email: emailAddress })
        .then(result => {
            if (result.length > 0)
                resolve(true)
            else
                resolve(false);
        })
        .catch(err => {
            reject(err);
        })
});

const createUser = (req: Request) => new Promise((resolve, reject) => {
    const u = createUserModel(req);
    UserModel.create(u)
        .then(doc => {
            req.session.userId = doc._id.toString();
            req.session.userType = doc.userType;
            req.session.isAuthenticated = true;
            req.session.name = doc.firstName;
            resolve(doc._id);
        })
        .catch(err => {
            reject(err);
        })
});

function updatePropertyThumbs(newProperty: Property, originalProperty: Property): Property {
    originalProperty.thumbs.forEach(t => {
        newProperty.thumbs.push(t);
    });
    return newProperty;
}

const createProperty = (req: Request, userId: string) => new Promise((resolve, reject) => {
    let prop = createPropertyModel(req, userId);
    if (req.body.propId && req.body.propId !== '') {
        PropertyModel.findOne({ '_id': req.body.propId })
            .then(result => {
                prop = updatePropertyThumbs(prop, result);
                return PropertyModel.updateOne({ '_id': req.body.propId }, prop)
            })
            .then(() => {
                resolve(req.body.propId);
            })
            .catch(err => {
                reject(err);
            })
    } else {
        PropertyModel.create(prop)
            .then((result) => {
                resolve(result._id);
            })
            .catch(err => {
                reject(err);
            })
    }
});

function createUserModel(req: Request): User {
    const u = new UserModel(req.body);
    u.userType = 'owner';
    u.registeredAt = new Date();
    u.subscriptionLength = 0;
    return u;
}

function createPropertyModel(req: Request, ownerId: string): Property {
    const p = new Property();
    p.ownerId = ownerId;
    p.saleType = req.body['sale-type'];
    p.type = req.body['property-type-input'];
    p.description = req.body['property-description'];

    p.propertyCounty = req.body.propertyCounty;
    p.propertyAddress = req.body.propertyAddress;
    p.propertyCity = req.body.propertyCity;
    p.propertyPostalCode = req.body.propertyPostalCode;
    p.price = req.body.price;
    p.view = req.body.view;
    p.lay = req.body.lay ? req.body.lay : '';

    p.utilitiesCost = req.body.utilitiesCost ? req.body.utilitiesCost : 0;
    p.deposit = req.body.deposit ? req.body.deposit : 0;
    p.minimalRentLength = req.body.minimalRentLength ? req.body.minimalRentLength : 0;
    p.createdAt = new Date();
    p.petAllowed = req.body.petAllowed ? req.body.petAllowed : 'none';
    p.smokingAllowed = req.body.smokingAllowed ? req.body.smokingAllowed : 'none';
    p.movingInDate = req.body.movingInDate ? new Date(req.body.movingInDate) : null;

    p.story = req.body.story ? req.body.story : 0;
    p.baseArea = req.body.baseArea ? req.body.baseArea : 0;
    p.buildingMaterial = req.body.buildingMaterial ? req.body.buildingMaterial : '';
    p.state = req.body.state ? req.body.state : '';
    p.halfRooms = req.body.halfRooms ? req.body.halfRooms : 0;
    p.wholeRooms = req.body.wholeRooms ? req.body.wholeRooms : 0;
    p.heating = req.body.heating ? req.body.heating : '';
    p.comfort = req.body.comfort ? req.body.comfort : '';
    p.buildingYear = req.body.buildingYear ? req.body.buildingYear : 0;
    p.houseType = req.body.houseType ? req.body.houseType : '';

    p.plotType = req.body.plotType ? req.body.plotType : '';
    p.plotArea = req.body.plotArea ? req.body.plotArea : '';
    p.extras = Property.getPropertyExtrasValue(req);

    p.propertyStatus = 'active';
    p.commissionRate = req.body.commissionRate;

    p.thumbs = getPropertyThumbs(req);
    return p;
}

function getPropertyThumbs(req: Request): [string] {
    const uploadedFiles = getUploadedFiles(req);
    const thumbs: [string] = [''];
    thumbs.pop();
    if (Array.isArray(uploadedFiles) && uploadedFiles.length > 0)
        for (const f of uploadedFiles)
            thumbs.push(f.filename);
    return thumbs;
}

function isThereOnlyForeignErrors(req: Request) {
    const saleType = req.params.saleType;
    const propertyType = req.params.propertyType;
    const isAuth = req.session.isAuthenticated === true ? true : false;
    const errors = validationResult(req).array();
    let isThere = false;
    const foreignErrors: ValidationError[] = [];
    errors.forEach(e => {
        if (isAuth)
            if (user.includes(e.param) && !foreignErrors.includes(e))
                foreignErrors.push(e);

        if (saleType === 'sale')
            if (rent.includes(e.param) && !foreignErrors.includes(e))
                foreignErrors.push(e);

        if (propertyType === 'flat') {
            if (!flat.includes(e.param) && !foreignErrors.includes(e) && !user.includes(e.param) && !rent.includes(e.param))
                foreignErrors.push(e);
        } else
            if (propertyType === 'house') {
                if (!house.includes(e.param) && !foreignErrors.includes(e) && !user.includes(e.param) && !rent.includes(e.param))
                    foreignErrors.push(e);
            } else if (propertyType === 'plot') {
                if (!plot.includes(e.param) && !foreignErrors.includes(e) && !user.includes(e.param) && !rent.includes(e.param))
                    foreignErrors.push(e);
            }
            else if (propertyType === 'business') {
                if (!business.includes(e.param) && !foreignErrors.includes(e) && !user.includes(e.param) && !rent.includes(e.param))
                    foreignErrors.push(e);
            }

    });
    isThere = foreignErrors.length === errors.length;
    return isThere;
}



const house = [
    'baseArea',
    'plotArea',
    'houseType',
    'buildingMaterial',
    'view',
    'state',
    'story',
    'wholeRooms',
    'heating',
    'comfort',
    'buildingYear',
    'price']

const flat = [
    'baseArea',
    'buildingMaterial',
    'view',
    'state',
    'story',
    'wholeRooms',
    'heating',
    'comfort',
    'buildingYear',
    'price']

const business = [
    'price',
    'baseArea',
    'state',
    'buildingYear',
    'story']

const plot = [
    'plotArea',
    'view',
    'plotType',
    'price']

const address = [
    'propertyCounty',
    'propertyCity',
    'propertyPostalCode',
    'propertyAddress',]

const user = [
    'email',
    'password',
    'lastName',
    'firstName',
    'phone',
    'agree-terms']


const rent = [
    'utilitiesCost',
    'minimalRentLength',
    'deposit',
    'movingInDate']

const fields: Map<FieldCategory, string[]> = new Map<FieldCategory, string[]>([
    [FieldCategory.Rent, rent],
    [FieldCategory.User_A, user],
    [FieldCategory.Address, address],
    [FieldCategory.Plot, plot],
    [FieldCategory.Flat, flat],
    [FieldCategory.Business, business],
    [FieldCategory.House, house]]
);


const errorMessages: Map<string, string[]> = new Map<string, string[]>(
    [
        ['email', [
            'Nem lehet üres',
            'Helytelen e-mail formátum']],
        ['password', ['A jelszó minimum 3 karakter']],
        ['lastName', ['Vezetéknév minimum 2 karakter']],
        ['firstName', ['Keresztnév minimum 3 karakter']],
        ['phone', ['Adjon meg egy érvényes telefonszámot!']],
        // ['county', ['Kérem válasszon']],
        // ['city', ['Város minimum 2 karakter']],
        // ['postalCode', ['Irányítószám 4 számjegy']],
        // ['address', ['Cím minimum 3 karakter']],

        ['propertyCounty', ['Kérem válasszon']],
        ['propertyCity', ['Város minimum 2 karakter']],
        ['propertyPostalCode', ['Irányítószám 4 számjegy']],
        ['propertyAddress', ['Cím minimum 3 karakter']],

        ['baseArea', ['Nem lehet üres, vagy 0']],
        ['buildingMaterial', ['Kérem válasszon']],
        ['view', ['Kérem válasszon']],
        ['state', ['Kérem válasszon']],
        ['story', ['Kérem válasszon']],
        ['wholeRooms', ['Nem lehet üres']],
        ['heating', ['Kérem válasszon']],
        ['comfort', ['Kérem válasszon']],
        ['buildingYear', ['Kérem válasszon']],
        ['price', ['Nem lehet üres, vagy 0']],
        ['plotArea', ['Nem lehet üres, vagy 0']],
        ['plotType', ['Kérem válasszon']],
        ['houseType', ['Kérem válasszon']],

        ['utilitiesCost', ['Nem lehet üres, vagy 0']],
        ['minimalRentLength', ['Nem lehet üres, vagy 0']],
        ['deposit', ['Nem lehet üres, vagy 0']],
        ['movingInDate', ['Kérem adjon meg dátumot']],
        ['agree-terms', ['A regisztrációhoz el kell fogadni a feltételeket']]
    ]
);

export { router, fields, errorMessages };