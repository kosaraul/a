import { body, CustomValidator } from 'express-validator';

enum Type {
    None = 0,
    User = 1,
    Property = 2
}

function validate() {
    return [
        body('email')
            .isLength({ min: 1 }).withMessage('Nem lehet üres')
            .isEmail().withMessage('Helytelen e-mail formátum'),
        body('password')
            .isLength({ min: 3 }).withMessage('A jelszó minimum 3 karakter'),
        body('lastName')
            .isLength({ min: 2 }).withMessage('Vezetéknév minimum 2 karakter'),
        body('firstName')
            .isLength({ min: 3 }).withMessage('Keresztnév minimum 3 karakter'),
        body('phone')
            .exists({ checkFalsy: true })
            .isLength({min: 11}).withMessage('Adjon meg egy érvényes telefonszámot!'),
        body('propertyCounty').custom(isValidSelect),
        body('propertyCity').isLength({ min: 2 }).withMessage('Város minimum 2 karakter'),
        body('propertyPostalCode').isNumeric().isLength({ min: 4, max: 4 }).withMessage('Irányítószám 4 számjegy'),
        body('propertyAddress').isLength({ min: 3 }).withMessage('Cím minimum 3 karakter'),

        body('baseArea').isInt({ min: 1 }).withMessage('Nem lehet üres, vagy 0'),
        body('buildingMaterial').custom(isValidSelect),
        body('view').custom(isValidSelect),
        body('state').custom(isValidSelect),
        body('story').custom(isValidSelect),
        body('wholeRooms').notEmpty().withMessage('Nem lehet üres'),
        body('heating').custom(isValidSelect),
        body('comfort').custom(isValidSelect),
        body('buildingYear').custom(isValidSelect),
        body('price').isInt({ min: 1 }).withMessage('Nem lehet üres, vagy 0'),
        body('plotArea').isInt({ min: 1 }).withMessage('Nem lehet üres, vagy 0'),
        body('plotType').custom(isValidSelect),
        body('houseType').custom(isValidSelect),

        body('utilitiesCost').isInt({ min: 1 }).withMessage('Nem lehet üres, vagy 0'),
        body('minimalRentLength').isInt({ min: 1 }).withMessage('Nem lehet üres, vagy 0'),
        body('deposit').isInt({ min: 1 }).withMessage('Nem lehet üres, vagy 0'),
        body('movingInDate').isDate().withMessage('Kérem adjon meg dátumot'),

        body('agree-terms')
        .custom(value => {
            if (value !== 'on') {
                throw new Error('err')
            } else {
                return value;
            }
        }).withMessage('A regisztrációhoz el kell fogadni a feltételeket')
    ]
}

const isValidSelect: CustomValidator = value => {
    if (value === 'none') {
        throw new Error('Kérem válasszon')
    } else {
        return value;
    }
};

export default validate;