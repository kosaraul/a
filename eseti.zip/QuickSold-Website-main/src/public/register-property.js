function selectPropertySaleType(type) {
    if (type === 'for-sale') {
        $('#sale-type').val('sale');
    } else {
        $('#sale-type').val('rent');
    }
    $('form').attr('action', '/register-property/change-type');
    $('form').attr('enctype', 'text');
    $('form').submit();
}

function selectPropertyType() {
    let type = $('#property-type').val();
    $('#property-type-input').val(type);
    $('form').attr('action', '/register-property/change-type');
    $('form').attr('enctype', 'text');
    $('form').submit();
}

function showMovingInDateInput() {
    const value = $('#moving-in-date-selector').val();
    $('#movingInDate').removeClass('hidden');
    if (value === 'now') {
        const now = new Date();
        const nowString = now.toISOString().split('T')[0]
        $('#movingInDate').val(nowString);
    }
}

function hideSuccessMessage() {
    let $success = $('.success');
    $success.addClass('fadeout');
}

$(document).ready(function () {
    hideSuccessMessage();
});