let plotTypes = null;
let $propRows = null;
let currentPage = 0;
let isUpdating = false;
window.onscroll = (ev) => {
    if (!isUpdating)
        if ((window.innerHeight + window.scrollY) >= document.getElementById('main-card').offsetHeight) {
            isUpdating = true;
            currentPage++;
            $.post('/properties/showmore', { currentPage: currentPage }, (result) => {
                if (plotTypes === null) {
                    $.post('/properties/plottypes', {}, (p) => {
                        plotTypes = createPlotTypesObject(p);
                        if (result.length > 0)
                            createNewProperties(result);
                        isUpdating = false;
                    })
                } else {
                    if (result.length > 0)
                        createNewProperties(result);
                    isUpdating = false;
                }
            });
        }
}

function addSeparator(nStr) {
    nStr += '';
    var x = nStr.split('.');
    var x1 = x[0];
    var x2 = x.length > 1 ? '.' + x[1] : '';
    var rgx = /(\d+)(\d{3})/;
    while (rgx.test(x1)) {
        x1 = x1.replace(rgx, '$1' + ' ' + '$2');
    }
    return x1 + x2;
}

function selectPropertyType() {
    let type = $('#property-type').val();
    let saleType = $('#property-sale-type-rent').is(':checked') ? 'rent' : 'sale';
    $('#property-type-input').val(type);
    $('#property-sale-type-input').val(saleType);
    $('form').attr('action', '/properties/change-type');
    $('form').submit();
}

function checkMinMaxValues(minField, maxField, strongerField) {
    let minValue = $('#' + minField).val();
    let maxValue = $('#' + maxField).val();
    if (maxValue == 0)
        $('#' + maxField).val('');
    if (minValue == 0)
        $('#' + minField).val('');
    minValue = $('#' + minField).val();
    maxValue = $('#' + maxField).val();
    if (minValue !== '' && maxValue !== '')
        if (parseInt(minValue) > parseInt(maxValue)) {
            if (minField === strongerField)
                $('#' + maxField).val(minValue);
            else if (maxField === strongerField)
                $('#' + minField).val(maxValue);
        }
}

function createPlotTypesObject(p) {
    let plotTypes = {};
    p.forEach(element => {
        plotTypes[element.value] = element.name;
    });
    return plotTypes;
}

function createNewProperties(properties) {
    if ($propRows === null)
        $propRows = $('.row.property-row');


    let newRowsCount = properties.length % 3 + Math.floor(properties.length / 3);
    let index = 0;
    for (let i = 0; i < newRowsCount; i++) {
        let row = $propRows.clone().first();
        let numba = currentPage * 8 + i + 1;
        let rowId = 'row-' + numba;
        row.attr('id', rowId);
        row.appendTo('#main-card')
        for (let j = 0; j < 3; j++) {
            if (properties.length > index)
                insertElement(properties[index], rowId, j);
            else {
                removeElement(rowId, j);
            }
            index++;
        }
    }
}

function removeElement(rowId, nth) {
    const selector = '#' + rowId + ' .col-xl-4';
    $(selector).each((i, e) => {
        if (nth === i) {
            e.style.display = 'none';
        }
    })
}

function insertElement(property, rowId, nth) {
    const selector = '#' + rowId + ' .col-xl-4';
    $(selector).each((i, e) => {
        if (nth === i) {
            fillUpCard(property, e);
        }
    })
}

function fillUpCard(property, element) {
    element.setAttribute('id', property['_id']);
    let id = '#' + element.id;
    $(id + ' .qs-listing-price').html(addSeparator(property.price) + ' Ft');
    $(id + ' .qs-listing-base-area').html(addSeparator(property.baseArea) + ' m<sup>2</sup>');
    let city = property.propertyCity;
    $(id + ' .qs-listing-city').html(city);
    let rooms = property.wholeRooms ? property.wholeRooms : '';
    if (property.halfRooms && property.halfRooms > 0)
        rooms += ' + ' + property.halfRooms;
    rooms += ' szoba'
    $(id + ' .qs-listing-rooms').html(rooms);
    if (property.type === 'plot') {
        if (plotTypes[property.plotType] && plotTypes[property.plotType] !== '')
            $(id + ' .qs-listing-rooms').html(plotTypes[property.plotType]);
        $(id + ' .qs-listing-base-area').html(addSeparator(property.plotArea) + ' m<sup>2</sup>');
    }
    $(id + ' .row .col-xl-12 img').remove();
    $(id + ' .row .col-xl-12 .qs-image').remove();
    if (property.thumbs && property.thumbs.length > 0) {
        $(id + ' .row .col-xl-12').append('<img src="https://quicksold-images.s3.eu-central-1.amazonaws.com/' + property.thumbs[0] + '" alt="">');
    } else {
        let elementHtml = '<div class="qs-image"><div style="text-align: center;"><i style="font-size: 20rem;" class="far fa-building"></i><p></p><h3>Nincs kép</h3></div></div>';
        $(id + ' .row .col-xl-12').append(elementHtml);
    }
    $(id).attr('onclick', 'location.href="/listing?propId=' + element.id + '"');
}