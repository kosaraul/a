$(document).ready(function () {
    setupNav();
    adjustPageSize();
});

function showDetailedSearch() {
    let $sB = $('#detailed-search-box');
    let isMobile = false;
    if ($sB.attr('id') == undefined) {
        isMobile = true;
        $sB = $('#mobile-detailed-search-box');
    }
    let currentDisplay = $sB.css('display');
    if (currentDisplay == 'none') {
        $('#main-search-button').css('visibility', 'hidden');
        if (isMobile)
            $sB.css('display', 'block');
        else
            $sB.css('display', 'flex');
        $('#detailed-search-toggle-button').html('Részletes kereső ˄');
    }
    else {
        $('#main-search-button').css('visibility', 'visible');
        $sB.css('display', 'none');
        $('#detailed-search-toggle-button').html('Részletes kereső ˅');
    }
    adjustPageSize();
}

function adjustPageSize() {
    let height = $('#main-card').height();
    let homeHeight = $('.home').height();
    let bgHeight = height - homeHeight + 200;
    let windowHeight = $(window).height();
    if ((homeHeight + bgHeight + 65) < windowHeight) {
        let finalHeight = windowHeight - (homeHeight + bgHeight + 65);
        finalHeight += bgHeight;
        bgHeight = finalHeight;
    }
    $('#main-background').height(bgHeight);
}

function setupNav() {
    $('.navTrigger').click(function () {
        $(this).toggleClass('active');
        $("#mainListDiv").toggleClass("show_list");
        $("#mainListDiv").fadeIn();

    });
}

function dismissMessage() {
    $('.success-msg-overlay-container').css('display', 'none');
    $('.blur-overlay').css('display', 'none');
}

function show(selector) {
    $('#' + selector).removeClass('hidden');
}

function hide(selector) {
    $('#' + selector).addClass('hidden');
}

function toggle(selector) {
    let $e = $('#' + selector);
    if ($e.hasClass('hidden'))
        $e.removeClass('hidden');
    else
        $e.addClass('hidden');
}

