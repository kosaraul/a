import { Schema, model } from 'mongoose';

export interface Description {
    category: string;
    type: string;
    value: string;
    name: string;
    index: number;
}

const schema = new Schema<Description>({
    category: { type: String, required: true },
    type: { type: String, required: true },
    value: { type: String, required: true },
    name: { type: String, required: true },
    index: { type: Number, required: true }
});

const DescriptionModel = model<Description>('Descriptions', schema);

export default DescriptionModel;