import { Schema, model, Query } from 'mongoose';
import { Request } from 'express';
import { uploadFile, deleteMultipleFiles } from '../aws';
import fs from 'fs';

export interface IProperty {
    houseType: string;
    saleType: string;
    type: string;
    ownerId: string;

    propertyCounty: string;
    propertyAddress: string;
    propertyCity: string;
    propertyPostalCode: string;
    price: number;
    view: string;
    lay: string;

    description: string;

    utilitiesCost: number;
    deposit: number;
    minimalRentLength: number;
    createdAt: Date;
    deletedAt: Date;
    petAllowed: string;
    smokingAllowed: string;
    movingInDate: Date;

    story: number;
    baseArea: number;
    buildingMaterial: string;
    state: string;
    halfRooms: number;
    wholeRooms: number;
    heating: string;
    comfort: string;
    buildingYear: string;

    plotType: string;
    plotArea: number;

    propertyStatus: string;
    commissionRate: string;

    thumbs: [string];
    extras: [string];
}

export class Property implements IProperty {
    propertyStatus: string;
    commissionRate: string;
    description: string;
    thumbs: [string];
    extras: [string];
    houseType: string;
    saleType: string;
    ownerId: string;
    type: string;
    propertyCounty: string;
    propertyAddress: string;
    propertyCity: string;
    propertyPostalCode: string;
    price: number;
    view: string;
    lay: string;
    utilitiesCost: number;
    deposit: number;
    minimalRentLength: number;
    createdAt: Date;
    deletedAt: Date;
    petAllowed: string;
    smokingAllowed: string;
    movingInDate: Date;
    story: number;
    baseArea: number;
    buildingMaterial: string;
    state: string;
    halfRooms: number;
    wholeRooms: number;
    heating: string;
    comfort: string;
    buildingYear: string;
    plotType: string;
    plotArea: number;

    static getPropertyExtrasValue(req: Request): [string] {
        const array: [string] = [''];
        array.pop();
        if (req.body['property-water'] && req.body['property-water'] === 'on')
            array.push('property-water');
        if (req.body['property-gas'] && req.body['property-gas'] === 'on')
            array.push('property-gas');
        if (req.body['property-electricity'] && req.body['property-electricity'] === 'on')
            array.push('property-electricity');
        if (req.body['property-drainage'] && req.body['property-drainage'] === 'on')
            array.push('property-drainage');
        if (req.body['property-fence'] && req.body['property-fence'] === 'on')
            array.push('property-fence');
        if (req.body['property-balcony'] && req.body['property-balcony'] === 'on')
            array.push('property-balcony');
        if (req.body['property-terrace'] && req.body['property-terrace'] === 'on')
            array.push('property-terrace');
        if (req.body['property-elevator'] && req.body['property-elevator'] === 'on')
            array.push('property-elevator');
        if (req.body['property-ac'] && req.body['property-ac'] === 'on')
            array.push('property-ac');
        if (req.body['property-parking-spot'] && req.body['property-parking-spot'] === 'on')
            array.push('property-parking-spot');
        if (req.body['property-garage'] && req.body['property-garage'] === 'on')
            array.push('property-garage');
        if (req.body['property-container'] && req.body['property-container'] === 'on')
            array.push('property-container');
        if (req.body['property-cellar'] && req.body['property-cellar'] === 'on')
            array.push('property-cellar');
        if (req.body['property-pool'] && req.body['property-pool'] === 'on')
            array.push('property-pool');
        if (req.body['property-alarm'] && req.body['property-alarm'] === 'on')
            array.push('property-alarm');
        if (req.body['property-notary-document'] && req.body['property-notary-document'] === 'on')
            array.push('property-notary-document');
        if (req.body['property-furnished'] && req.body['property-furnished'] === 'on')
            array.push('property-furnished');
        if (req.body['property-appliances'] && req.body['property-appliances'] === 'on')
            array.push('property-appliances');
        return array;
    }

}

const propSchema = new Schema<IProperty>({
    commissionRate: { type: String },
    propertyStatus: { type: String },
    description: { type: String },
    extras: { type: [String] },
    thumbs: { type: [String] },
    houseType: { type: String },
    saleType: { type: String },
    ownerId: { type: String },
    type: { type: String },
    propertyCounty: { type: String },
    propertyAddress: { type: String },
    propertyCity: { type: String },
    propertyPostalCode: { type: String },
    price: { type: Number },
    view: { type: String },
    lay: { type: String },
    utilitiesCost: { type: Number },
    deposit: { type: Number },
    minimalRentLength: { type: Number },
    createdAt: { type: Date },
    deletedAt: { type: Date },
    petAllowed: { type: String },
    smokingAllowed: { type: String },
    movingInDate: { type: Date },
    story: { type: Number },
    baseArea: { type: Number },
    buildingMaterial: { type: String },
    state: { type: String },
    halfRooms: { type: Number },
    wholeRooms: { type: Number },
    heating: { type: String },
    comfort: { type: String },
    buildingYear: { type: String },
    plotType: { type: String },
    plotArea: { type: Number }
}
);

propSchema.pre('save', function (next) {
    const prop = this;
    for (const thumb of prop.thumbs) {
        uploadFile('./uploads/' + thumb, thumb)
            .then(result => {
                try {
                    fs.unlinkSync('./uploads/' + thumb);
                } catch (error) {
                    console.log('photo not found: ' + thumb);
                }
            })
            .catch(err => {
                console.log(err);
            })
    }
    next();
});

propSchema.pre('deleteOne', { document: true, query: false }, function (next) {
    const prop = this as any;
    deleteMultipleFiles(prop.thumbs)
        .then(result => {
            next();
        })
});

propSchema.pre('updateOne', function (next) {
    const prop = this.getUpdate();
    if (prop.thumbs)
        for (const thumb of prop.thumbs) {
            uploadFile('./uploads/' + thumb, thumb)
                .then(result => {
                    try {
                        fs.unlinkSync('./uploads/' + thumb);
                    } catch (error) {
                        console.log(error);
                    }
                })
                .catch(err => {
                    console.log(err);
                })
        }
    next();
});

const PropertyModel = model<IProperty>('Property', propSchema);

export default PropertyModel;