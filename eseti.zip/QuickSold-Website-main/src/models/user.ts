import { Schema, model, Model } from 'mongoose';
import bcrypt from 'bcryptjs';

interface IUser {
    firstName: string;
    lastName: string;
    password: string;
    email: string;
    phone: string;
    companyName: string;
    vatNumber: string;
    address: string;
    city: string;
    county: string;
    postalCode: string;
    userType: string;
    registeredAt: Date;
    lastPaidAt: Date;
    subscriptionLength: number;
}

export class User implements IUser {
    firstName: string;
    lastName: string;
    password: string;
    email: string;
    phone: string;
    companyName: string;
    vatNumber: string;
    address: string;
    city: string;
    county: string;
    postalCode: string;
    userType: string;
    registeredAt: Date;
    lastPaidAt: Date;
    subscriptionLength: number;
}

export const UserSchema = new Schema<IUser>({
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    password: { type: String, required: true },
    email: { type: String, required: true },
    phone: { type: String, required: true },
    companyName: { type: String },
    vatNumber: { type: String },
    address: { type: String },
    city: { type: String },
    county: { type: String },
    postalCode: { type: String },
    userType: { type: String, required: true },
    registeredAt: { type: Date, required: true },
    lastPaidAt: { type: Date },
    subscriptionLength: { type: Number, required: true }
});

UserSchema.pre('save', function (next) {
    const saltOrRounds = 10;
    const user = this;
    if (user.password)
        bcrypt.hash(user.password, saltOrRounds)
            .then((result) => {
                user.password = result;
                next();
            })
            .catch(err => {
                console.log(err);
                next();
            });
    else next();
});

UserSchema.pre('updateOne', function (next) {
    const saltOrRounds = 10;
    const user = this.getUpdate().$set;
    if (user.password !== '')
        bcrypt.hash(user.password, saltOrRounds)
            .then((result) => {
                user.password = result;
                next();
            })
            .catch(err => {
                console.log(err);
                next();
            })
    else
        next();
});




const UserModel = model<IUser>('Users', UserSchema);

export default UserModel;