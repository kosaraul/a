import { Result, ValidationError } from 'express-validator';

const objectify = function objtify(errors: Result<ValidationError>) {
  const a = errors.array();
  const obj = {} as any;
  a.forEach(e => {
    obj[e.param] = e.msg;
  });
  return obj;
}

export default objectify;