import { NextFunction, Request, Response } from 'express';

const authCheck = (req: Request, res: Response, next: NextFunction) => {
    if (req.session.isAuthenticated)
        return next();
    else
        return next(new Error('Not authenticated'));
}

export default authCheck;