import nodemailer from 'nodemailer';

export const emailAddress = 'ugyfelszolgalat@quicksold.hu';

const transporter = nodemailer.createTransport({
    host: "smtp.forpsi.com",
    port: 465,
    auth: {
        user: "ugyfelszolgalat@quicksold.hu",
        pass: "U2019h@ppy",
    },
});

export function sendEmail(targetAddress: string, subject: string, text: string) {
    const mailOptions = {
        from: emailAddress,
        to: targetAddress,
        subject,
        text
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
}

export function sendHtmlEmail(targetAddress: string, subject: string, text: string, html?: string) {
    const mailOptions = {
        from: emailAddress,
        to: targetAddress,
        subject,
        text,
        html: '<!DOCTYPE html>'+ html
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.log(error);
        } else {
            console.log('Email sent: ' + info.response);
        }
    });
}