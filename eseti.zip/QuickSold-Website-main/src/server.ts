
import express from 'express';
import expressLayouts from 'express-ejs-layouts';
import cookieSession from 'cookie-session';
import path from 'path';
import contact from './routes/contact';
import about from './routes/about';
import admin from './routes/admin';
import login from './routes/login';
import logout from './routes/logout';
import acceptCookie from './routes/accept-cookie';
import properties from './routes/properties';
import propRedirect from './routes/properties-redirect';
import registerUser from './routes/register-user';
import listing from './routes/listing';
import { router as registerProperty } from './routes/register-property';
import mongoose, { FilterQuery } from 'mongoose';
import { IProperty } from './models/property';
const url = 'mongodb+srv://quicksold:Ingatlan22@cluster0.0dv67.mongodb.net/quicksold_db?retryWrites=true&w=majority';
// const url = 'mongodb+srv://embraiz:Sasmadar11@cluster0.0kq3c.gcp.mongodb.net/quicksold_db?retryWrites=true&w=majority';

declare module "express-session" {
  interface SessionData {
    username: string,
    isAuthenticated: boolean,
    name: string,
    userId: string,
    userType: string,
    searchParams: FilterQuery<IProperty>,
    mobileSearchParams: any,
    cookieAccepted: boolean
  }
}

const app = express();
const port = 8080;

const middlewares = [
  expressLayouts,
  express.static(__dirname + '/public'),
  express.urlencoded({ extended: true }),
  cookieSession({
    secret: 'quicksold-secret-key-55uJnG',
    keys: ['quicksold-secret-cookie-4aFygh']
  })
];

app.set("layout extractScripts", true);
app.set("layout extractStyles", true);

mongoose.connect(url);
const db = mongoose.connection;

db.once('open', () => {
  console.log('MongoDB connection open!');
});

app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

app.use(middlewares);
app.use('/', propRedirect);
app.use('/accept-cookie', acceptCookie);
app.use('/contact', contact);
app.use('/about', about);
app.use('/login', login);
app.use('/logout', logout);
app.use('/admin', admin);
app.use('/listing', listing);
app.use('/properties', properties);
app.use('/register-user', registerUser);
app.use('/register-property', registerProperty);

app.listen(port, () => {
  console.log(`App running at http://localhost:${port}`);
});