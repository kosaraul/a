import AWS from 'aws-sdk';
import fs from 'fs';

const ID = 'AKIA2ELMYJ6YVH64U6GF';
const SECRET = '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';

const BUCKET_NAME = 'quicksold-images';

const s3 = new AWS.S3({
    accessKeyId: ID,
    secretAccessKey: SECRET
});

const uploadFile = (fileName: string, targetFileName: string) => new Promise((resolve, reject) => {
    try {
        const fileContent = fs.readFileSync(fileName);
        const params = {
            Bucket: BUCKET_NAME,
            Key: targetFileName,
            Body: fileContent,
            ACL: 'public-read'
        };
        s3.upload(params, (err: Error, data: AWS.S3.ManagedUpload.SendData) => {
            if (err) {
                reject(err);
            }
            console.log(`File uploaded successfully. ${data.Location}`);
            resolve('success');
        });
    } catch (e) {
        console.log(e);
        reject(e);
    }
});

const deleteMultipleFiles = (fileNames: [string]) => new Promise((resolve, reject) => {
    try {
        if (fileNames && fileNames.length > 0) {
            const Delete: any = { Objects: [] };
            fileNames.forEach(e => {
                Delete.Objects.push({ 'Key': e });
            })
            const params = {
                Bucket: BUCKET_NAME,
                Delete
            };
            s3.deleteObjects(params, (err: Error, data: AWS.S3.DeleteObjectOutput) => {
                if (err) {
                    reject(err);
                }
                console.log(`Files deleted successfully. ${data}`);
                resolve('success');
            });
        } else {
            resolve('success');
        }

    } catch (e) {
        console.log(e);
        reject(e);
    }
});

const deleteFile = (fileName: string) => new Promise((resolve, reject) => {
    try {
        const params = {
            Bucket: BUCKET_NAME,
            Key: fileName
        };
        s3.deleteObject(params, (err: Error, data: AWS.S3.DeleteObjectOutput) => {
            if (err) {
                reject(err);
            }
            console.log(`File deleted successfully. ${fileName}`);
            resolve('success');
        });
    } catch (e) {
        console.log(e);
        reject(e);
    }
});

async function emptyS3Directory(dir: string) {
    const listParams = {
        Bucket: BUCKET_NAME,
        Prefix: dir
    };

    const listedObjects = await s3.listObjectsV2(listParams).promise();

    if (listedObjects.Contents.length === 0) return;

    const deleteParams: AWS.S3.DeleteObjectsRequest = {
        Bucket: BUCKET_NAME,
        Delete: { Objects: [] }
    };

    listedObjects.Contents.forEach(({ Key }) => {
        deleteParams.Delete.Objects.push({ Key });
    });

    await s3.deleteObjects(deleteParams).promise();
}

export { uploadFile, emptyS3Directory, deleteFile, deleteMultipleFiles };